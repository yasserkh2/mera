# coding=utf-8
# based on Optimum library code
#
from typing import TYPE_CHECKING

from transformers.utils import OptionalDependencyNotAvailable, _LazyModule

_import_structure = {
    "modeling_decoder": ["MERAModelForCausalLM"],
    "modeling_diffusion": ["MERAStableDiffusionPipeline"],
    "modeling_mera": [
        "MERAModelForImageClassification",
        "MERAModelForSemanticSegmentation",
        "MERAModelForSequenceClassification",
        "MERAModelForZeroShotImageClassification",
        "MERAModelForQuestionAnswering",
        "MERAModelForObjectDetection",
    ],
    "modeling_vision_encoder_decoder": [
        "MERAVisionEncoderDecoderModel",
    ],
    "modeling_seq2seq": [
        "MERAModelForSpeechSeq2Seq",
    ],
}


# Direct imports for type-checking
if TYPE_CHECKING:
    pass
else:
    import sys

    sys.modules[__name__] = _LazyModule(
        __name__, globals()["__file__"], _import_structure, module_spec=__spec__
    )
