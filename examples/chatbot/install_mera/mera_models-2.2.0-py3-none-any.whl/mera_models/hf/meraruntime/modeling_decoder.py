# coding=utf-8
# based on Optimum library code
#
"""Classes handling causal-lm related architectures in MERA Runtime."""

import logging
import os
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple, Union

import numpy as np
import onnx
import onnxruntime
import packaging
import torch
from optimum.utils import check_if_transformers_greater
from transformers import AutoModelForCausalLM, GenerationConfig

from ..modeling_outputs import CausalLMOutputWithPast
from .modeling_mera import MERAModel

if TYPE_CHECKING:
    from transformers import PretrainedConfig

if check_if_transformers_greater("4.25.0"):
    from transformers.generation import GenerationMixin
else:
    from transformers.generation_utils import GenerationMixin


logger = logging.getLogger(__name__)


_TOKENIZER_FOR_DOC = "AutoTokenizer"


class MERAModelForCausalLM(MERAModel, GenerationMixin):
    """
    MERA model with a causal language modeling head for MERA Runtime inference.
    """

    auto_model_class = AutoModelForCausalLM
    main_input_name = "input_ids"
    _supports_cache_class = False

    def __init__(
        self,
        model: "MERARuntime",
        config: "PretrainedConfig",
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        preprocessors: Optional[List] = None,
        generation_config: Optional[GenerationConfig] = None,
        use_cache: Optional[bool] = None,
        **kwargs,
    ):
        super().__init__(model, config, model_save_dir, preprocessors, **kwargs)

        self.num_pkv = 2
        from optimum.utils.normalized_config import NormalizedConfigManager

        self.normalized_config = NormalizedConfigManager.get_normalized_config_class(
            config.model_type
        )(config)
        self.use_cache = False

        if generation_config is None:
            generation_config = GenerationConfig.from_model_config(config)
        self.generation_config = generation_config

        # --- input shapes info
        # looks like this:
        # {'input_ids': [[1, 16], 'int64'],
        # 'attention_mask': [[1, 16], 'int64'],
        # 'position_ids': [[1, 16], 'int64']}
        self.input_info_dt = kwargs["input_info_dt"]

        # --- temp var for storing running inputs
        self._prev_inputs = []
        self._prev_outputs = []
        self._prev_outputs_len = 0
        # ----------------

    @classmethod
    def from_pretrained(
        cls,
        model_id: Union[str, Path],
        export: bool = False,
        force_download: bool = False,
        use_auth_token: Optional[str] = None,
        cache_dir: Optional[str] = None,
        subfolder: str = "",
        config: Optional["PretrainedConfig"] = None,
        local_files_only: bool = False,
        **kwargs,
    ):
        r"""
        Instantiate a pretrained model from a pre-trained model configuration.

        Args:
            model_id (`Union[str, Path]`):
                Can be either:
                    - A string, the *model id* of a pretrained model hosted inside a model repo on huggingface.co.
                        Valid model ids can be located at the root-level, like `bert-base-uncased`, or namespaced under a
                        user or organization name, like `dbmdz/bert-base-german-cased`.
                    - A path to a *directory* containing a model saved using [`~OptimizedModel.save_pretrained`],
                        e.g., `./my_model_directory/`.
            export (`bool`, defaults to `False`):
                Defines whether the provided `model_id` needs to be exported to the targeted format.
            force_download (`bool`, defaults to `True`):
                Whether or not to force the (re-)download of the model weights and configuration files, overriding the
                cached versions if they exist.
            use_auth_token (`Optional[Union[bool,str]]`, defaults to `None`):
                Deprecated. Please use the `token` argument instead.
            cache_dir (`Optional[str]`, defaults to `None`):
                Path to a directory in which a downloaded pretrained model configuration should be cached if the
                standard cache should not be used.
            subfolder (`str`, defaults to `""`):
                In case the relevant files are located inside a subfolder of the model repo either locally or on huggingface.co, you can
                specify the folder name here.
            config (`Optional[transformers.PretrainedConfig]`, defaults to `None`):
                The model configuration.
            local_files_only (`Optional[bool]`, defaults to `False`):
                Whether or not to only look at local files (i.e., do not try to download the model).
        """
        return super().from_pretrained(
            model_id,
            export=export,
            force_download=force_download,
            use_auth_token=use_auth_token,
            cache_dir=cache_dir,
            subfolder=subfolder,
            config=config,
            local_files_only=local_files_only,
            row_fetch=True,
            **kwargs,
        )

    def forward(
        self,
        input_ids: torch.LongTensor,
        attention_mask: Optional[torch.FloatTensor] = None,
        encoder_hidden_states: Optional[torch.FloatTensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Tuple[Tuple[torch.Tensor]]] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache_branch: bool = None,
        **kwargs,
    ) -> CausalLMOutputWithPast:
        # adding use_cache_branch in the signature here is just a hack for IO Binding
        use_torch = isinstance(input_ids, torch.Tensor)

        inputs = {}
        known_output_shapes = {}
        use_cache_branch = None
        loss = None

        # fill in empty input if necessary
        # https://discuss.huggingface.co/t/llama-position-ids/75870
        check_attn = "attention_mask" in self.inputs_names and attention_mask is None
        check_pos = "position_ids" in self.inputs_names and position_ids is None
        filled = {}
        if check_attn or check_pos:
            filled = self.prepare_inputs_for_generation(input_ids)
        if check_attn:
            attention_mask = filled["attention_mask"]
        if check_pos:
            position_ids = filled["position_ids"]

        # generate final input dict
        inputs["input_ids"] = (
            input_ids.cpu().detach().numpy() if use_torch else input_ids
        )

        if "attention_mask" in self.inputs_names:
            inputs["attention_mask"] = (
                attention_mask.cpu().detach().numpy() if use_torch else attention_mask
            )

        if "labels" in self.inputs_names:
            inputs["labels"] = labels.cpu().detach().numpy() if use_torch else labels

        if "position_ids" in self.inputs_names:
            if position_ids is None:
                raise ValueError(
                    "position_ids was not passed but is a required input for this MERA model."
                )
            inputs["position_ids"] = (
                position_ids.cpu().detach().numpy() if use_torch else position_ids
            )

        logger.debug(
            f"Running model single forward with input {inputs['input_ids'].shape}"
        )

        # --- pad/shift the inputs
        cur_seq = inputs["input_ids"].shape[-1]
        max_seq = self.input_info_dt["input_ids"][0][1]
        start = cur_seq - max_seq
        pad_width = ((0, 0), (0, max_seq - cur_seq))
        start_token_id = inputs["input_ids"][0, 0]
        tmp_inputs = {}
        if cur_seq < max_seq:
            # pad
            for k, v in inputs.items():
                inputs[k] = np.pad(
                    v,
                    pad_width=pad_width,
                    mode="constant",
                    constant_values=0,
                )
        elif cur_seq > max_seq:
            # shift
            for k, v in inputs.items():
                tmp_inputs[k] = v.copy()
                inputs[k] = v[:, -max_seq:]
        # ---------------------

        # --- padding the encoder_hidden_states
        if "encoder_hidden_states" in self.input_info_dt:
            padded_encoder_hidden_states = torch.zeros(
                self.input_info_dt["encoder_hidden_states"][0]
            )
            padded_encoder_hidden_states[0, 0 : encoder_hidden_states.shape[1]] = (
                encoder_hidden_states
            )
            inputs["encoder_hidden_states"] = (
                padded_encoder_hidden_states.cpu().detach().numpy()
            )
        # ---------------------

        mera_runner = self.model.set_input(inputs).run()

        # import time

        # start = time.perf_counter()

        # --- post-processing
        cur_fetch = min(cur_seq, max_seq)
        if self.row_fetch:
            out_row = [mera_runner.get_output_row(cur_fetch - 1)]
        else:
            outputs = mera_runner.get_outputs()
            out_row = [output[:, cur_fetch - 1 : cur_fetch] for output in outputs]

        if self.measure_latency:
            self.measure_estimated_latency(mera_runner)

        if self._prev_outputs_len == 0:
            self._prev_outputs_len = max_seq
            self._prev_outputs = [
                np.zeros((out_row[0].shape[0], max_seq, out_row[0].shape[2]))
                for _ in out_row
            ]
        if cur_seq >= self._prev_outputs_len:
            self._prev_outputs_len *= 2
            self._prev_outputs = [
                np.resize(v, (v.shape[0], self._prev_outputs_len, v.shape[2]))
                for v in self._prev_outputs
            ]
        for i, v in enumerate(out_row):
            self._prev_outputs[i][:, cur_seq - 1] = v

        self._prev_inputs = inputs
        outputs = [prev_output[:, :cur_seq] for prev_output in self._prev_outputs]

        # end = time.perf_counter()
        # print(f"{cur_seq}: Post-processing time: {(end - start) * 1000} ms")

        logits = torch.tensor(outputs[self.output_names["logits"]]).to(self.device)
        if "loss" in self.output_names:
            loss = torch.tensor(outputs[self.output_names["loss"]]).to(self.device)

        return CausalLMOutputWithPast(
            loss=loss, logits=logits, past_key_values=past_key_values
        )

    def prepare_inputs_for_generation(self, input_ids, past_key_values=None, **kwargs):
        # Adapted from transformers.models.gpt2.modeling_gpt2.GPT2LMHeadModel.prepare_inputs_for_generation
        # if model is used as a decoder in encoder-decoder model, the decoder attention mask is created on the fly
        attention_mask = kwargs.get("attention_mask", None)
        use_cache = kwargs.get("use_cache", None)
        position_ids = kwargs.get("position_ids", None)
        use_torch = isinstance(input_ids, torch.Tensor)

        if "attention_mask" in self.input_info_dt and attention_mask is None:
            attention_mask = torch.ones(input_ids.shape)
            attention_mask.masked_fill_(input_ids == 0, 0)
            if not use_torch:
                attention_mask = attention_mask.cpu().detach().numpy()

        if attention_mask is not None and position_ids is None:
            # create position_ids on the fly for batch generation
            position_ids = attention_mask.long().cumsum(-1) - 1
            position_ids.masked_fill_(attention_mask == 0, 1)

        return {
            "input_ids": input_ids,
            "past_key_values": past_key_values,
            "use_cache": use_cache,
            "position_ids": position_ids,
            "attention_mask": attention_mask,
        }

    def can_generate(self):
        """Returns True to validate the check that the model using `GenerationMixin.generate()` can indeed generate."""
        return True
