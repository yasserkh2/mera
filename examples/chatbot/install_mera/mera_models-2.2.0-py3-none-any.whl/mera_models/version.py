__version__ = "2.2.0"
__release_date__ = "23/12/2024"
