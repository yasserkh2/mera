import textwrap

import cv2
import numpy as np


def draw_outlined_text(
    image,
    txt,
    txt_x,
    txt_y,
    font=cv2.FONT_HERSHEY_SIMPLEX,
    font_scale=0.6,
    thick=4,
    c_in=(255, 255, 255),
    c_out=(0, 0, 0),
):
    # outline
    cv2.putText(image, txt, (txt_x, txt_y), font, font_scale, c_out, thick, cv2.LINE_AA)
    # core
    thick_in = max(1, thick // 4)
    cv2.putText(
        image, txt, (txt_x, txt_y), font, font_scale, c_in, thick_in, cv2.LINE_AA
    )


def draw_paragraph(
    image,
    paragraph,
    txt_x=30,
    txt_y=30,
    line_spacing=30,
    font_scale=0.6,
    thick=4,
):
    for line in paragraph:
        draw_outlined_text(
            image, line, txt_x, txt_y, font_scale=font_scale, thick=thick
        )
        txt_y += line_spacing


def draw_text_as_overlay(
    text,
    overlay,
    max_char_per_line,
    font_scale,
    thick=4,
    font=cv2.FONT_HERSHEY_SIMPLEX,
    line_spacing_scale=1.2,
):
    # get text height measurement
    example = "asdf"
    (w, h), baseline = cv2.getTextSize(example, font, font_scale, thick)
    txt_h = h + baseline
    line_sp = int(txt_h * line_spacing_scale)

    # make a paragraph
    para = textwrap.wrap(text, width=max_char_per_line)

    # create overlay
    if overlay is None:
        line_num = len(para)
        min_height = max(600, int(line_num * (txt_h + line_sp / 4)))
        min_width = 600
        overlay = np.zeros((min_height, min_width, 3), dtype=np.uint8)

    # draw actual texts
    draw_paragraph(
        overlay,
        para,
        txt_x=txt_h,
        txt_y=txt_h,
        line_spacing=line_sp,
        font_scale=font_scale,
    )

    return overlay


def save_text_as_image_file(
    save_path,
    txt,
    overlay=None,
    max_char_per_line=50,
    font_scale=0.6,
    thick=4,
    font=cv2.FONT_HERSHEY_SIMPLEX,
    line_spacing_scale=1.2,
):
    cv2.imwrite(
        save_path,
        draw_text_as_overlay(
            txt,
            overlay,
            max_char_per_line,
            font_scale,
            thick,
            font,
            line_spacing_scale,
        ),
    )


def get_device_target(device_str):
    from mera.mera_deployment import DeviceTarget

    if isinstance(device_str, DeviceTarget):
        return device_str

    dt = {str(e.value[0]).lower(): e for e in DeviceTarget}
    dt.update(
        {
            "intel": DeviceTarget.INTEL_IA420,
            "xilinx": DeviceTarget.XILINX_U50,
            "sakura1": DeviceTarget.SAKURA_1,
            "sakura_1": DeviceTarget.SAKURA_1,
        }
    )

    try:
        new_enum = DeviceTarget.SAKURA_2
    except:
        new_enum = DeviceTarget.SAKURA_1
    dt.update({"sakura2": new_enum})

    if device_str.lower() not in dt:
        raise ValueError(
            f"{device_str} is not supported. Available choices are {list(dt.keys())}."
        )
    return dt[device_str]


def get_device_platform(device_str):
    from mera import Platform

    if isinstance(device_str, Platform):
        return device_str

    dt = {str(e.value).lower(): e for e in Platform}
    dt.update(
        {
            "sakura1": Platform.SAKURA_1,
            "sakura_1": Platform.SAKURA_1,
            "sakura2": Platform.SAKURA_2C,
            "sakura_2": Platform.SAKURA_2C,
            "sakura_2c": Platform.SAKURA_2C,
        }
    )

    if device_str.lower() not in dt:
        raise ValueError(
            f"{device_str} is not supported. Available choices are {list(dt.keys())}."
        )
    return dt[device_str]


def get_target(target_str):
    from mera import Target

    if isinstance(target_str, Target):
        return target_str

    # str -> enum obj
    dt = {str(e.value[0]).lower(): e for e in Target}
    dt["cpu"] = Target.Interpreter
    dt["bf16"] = Target.InterpreterBf16
    if target_str.lower() not in dt:
        raise ValueError(
            f"{target_str} is not supported. Available choices are {list(dt.keys())}."
        )
    return dt[target_str.lower()]


def flags_to_dict(flags):
    dt = {}
    for word in flags.split(","):
        k, v = word.split("=")
        dt[k.strip()] = v.strip()
    return dt
