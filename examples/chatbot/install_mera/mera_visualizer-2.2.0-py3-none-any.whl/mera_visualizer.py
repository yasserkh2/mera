# my_visualizer.py
from backend.app import app
import argparse
from pathlib import Path

# from backend.json_graph_reader import get_graph_from_json


def main():
    parser = argparse.ArgumentParser(description="MERA Visualizer")
    parser.add_argument(
        "--port", type=int, default=5566, help="Port to run the server on"
    )
    parser.add_argument(
        "--debug", action="store_true", help="Enable Flask debug mode (default: off)"
    )
    parser.add_argument(
        "--host",
        type=str,
        default="127.0.0.1",
        choices=["127.0.0.1", "0.0.0.0"],
        help="Use '127.0.0.1' for local only (default), or '0.0.0.0' for server/network access.",
    )
    args = parser.parse_args()

    # determine the path to the static files
    current_dir = Path(__file__).parent.resolve()
    static_folder = current_dir / "frontend" / "build"
    app.static_folder = str(static_folder)
    # Run the app
    app.run(host=args.host, port=args.port, debug=args.debug)


if __name__ == "__main__":
    main()
