# coding=utf-8
# based on Optimum library code
#
"""MERAModelForXXX classes, allowing to run Models using the same API as Transformers library."""

import glob
import json
import logging
import os
import re
import shutil
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Set, Tuple, Union

import mera
import numpy as np
import onnxruntime as ort
import torch
from huggingface_hub import HfApi, HfFolder, hf_hub_download
from huggingface_hub.utils import EntryNotFoundError
from optimum.exporters import TasksManager
from optimum.exporters.onnx import main_export as main_export_onnx
from transformers import (
    AutoConfig,
    AutoModel,
    AutoModelForAudioClassification,
    AutoModelForAudioFrameClassification,
    AutoModelForAudioXVector,
    AutoModelForCTC,
    AutoModelForImageClassification,
    AutoModelForMaskedLM,
    AutoModelForMultipleChoice,
    AutoModelForObjectDetection,
    AutoModelForQuestionAnswering,
    AutoModelForSemanticSegmentation,
    AutoModelForSequenceClassification,
    AutoModelForTokenClassification,
    AutoModelForZeroShotImageClassification,
)
from transformers.models.clip.modeling_clip import CLIPOutput

from ...utils import get_device_platform, get_device_target, get_target
from ...utils import quantize_with_mera_wrapper
from ..modeling_base import OptimizedModel
from ..modeling_outputs import (
    ImageClassifierOutput,
    ObjectDetectionOutput,
    QuestionAnsweringModelOutput,
    SemanticSegmenterOutput,
    SequenceClassifierOutput,
)

if TYPE_CHECKING:
    from transformers import PretrainedConfig


logger = logging.getLogger(__name__)


_TOKENIZER_FOR_DOC = "AutoTokenizer"
_FEATURE_EXTRACTOR_FOR_DOC = "AutoFeatureExtractor"
_PROCESSOR_FOR_DOC = "AutoProcessor"


_MERA_DEPLOYMENT_NAME = "mera_deployment"
_MERA_CONFIG_NAME = "mera.json"
_ONNX_MODEL_NAME = "model.onnx"
_ONNX_CONFIG_NAME = "config.json"
_QTZED_MERA_MODEL_NAME = "model.mera"
_QTZED_MERA_MODEL_QPARAM_NAME = "q_params.json"
_QTZED_MERA_DEPLOY_DIR = "qtzer_deploy"


def _pad_inputs_for_text_model(inputs, max_seq, cur_seq=-1):
    if cur_seq == -1:  # find out from current input
        cur_seq = inputs["input_ids"].shape[-1]

    if max_seq == cur_seq:  # already padded
        return inputs

    pad_width = ((0, 0), (0, max_seq - cur_seq))
    for k, v in inputs.items():
        inputs[k] = np.pad(
            v,
            pad_width=pad_width,
            mode="constant",
            constant_values=0,
        )
    return inputs


class classproperty:
    def __init__(self, getter):
        self.getter = getter

    def __get__(self, instance, owner):
        return self.getter(owner)


class MERAModel(OptimizedModel):
    """
    Base class for implementing models using MERA Runtime.
    """

    model_type = "mera_model"
    auto_model_class = AutoModel

    @classmethod
    def _auto_model_to_task(cls, auto_model_class):
        """
        Get the task corresponding to a class (for example AutoModelForXXX in transformers).
        """
        return TasksManager.infer_task_from_model(auto_model_class)

    def __init__(
        self,
        model: "MERAModel",
        config: "PretrainedConfig",
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        preprocessors: Optional[List] = None,
        row_fetch: bool = False,
        **kwargs,
    ):
        super().__init__(model, config)

        self.device = torch.device("cpu")
        self.preprocessors = preprocessors if preprocessors is not None else []

        # Registers the MERAModelForXXX classes into the transformers AutoModel classes to avoid warnings when creating
        # a pipeline https://github.com/huggingface/transformers/blob/cad61b68396a1a387287a8e2e2fef78a25b79383/src/transformers/pipelines/base.py#L863
        AutoConfig.register(self.model_type, AutoConfig)
        if hasattr(self.auto_model_class, "register"):
            self.auto_model_class.register(AutoConfig, self.__class__)

        # --- load input/output shapes
        # TODO: currently this might only work on text-generation
        # need to generalize to other categories.
        # -- it looks like this currently
        # self.inputs_names = {"input_ids": 0, "attention_mask": 1, "position_ids": 2}
        assert (
            "input_info_dt" in kwargs
        ), "input_info_dt is needed for MERAModel cls init"
        self.input_info_dt = kwargs["input_info_dt"]
        self.inputs_names = {k: i for i, k in enumerate(kwargs["input_info_dt"])}

        self.output_names = {"logits": 0}
        self.measure_latency = kwargs.get("measure_latency", False)
        self.estimated_latency = None
        self.row_fetch = row_fetch
        # -----------------------

    # TODO: why do we make device a property since we are only access the value, and do not do any check when setting the value?
    @property
    def device(self) -> torch.device:
        """
        `torch.device`: The device on which the module is (assuming that all the module parameters are on the same
        device).
        """
        return self._device

    @device.setter
    def device(self, value: torch.device):
        self._device = value

    def forward(self, *args, **kwargs):
        raise NotImplementedError

    # TODO: Only measuring for SimulatorBf16, not IP.
    def measure_estimated_latency(self, mera_runner):
        try:
            metrics = mera_runner.get_runtime_metrics()
            if isinstance(metrics, list):  # mera1
                sim_us = [float(x["sim_time_us"]) for x in metrics]
            elif isinstance(metrics, dict):  # mera2
                sim_us = [float(metrics[x]["sim_time_us"]) for x in metrics]

            self.estimated_latency = sum(sim_us) / 1000
        except:
            pass

    @staticmethod
    def load_model(
        path: Union[str, Path],
        target: Union[str, mera.Target],
        device_target: Union[str, mera.mera_deployment.DeviceTarget],
        row_fetch: bool = False,
        device_ids : Union[int, List[int]] = None,
    ) -> "MERARuntimeClass":
        target = get_target(target)
        device_target = get_device_target(device_target)
        ip1 = mera.load_mera_deployment(path, target=target)

        if row_fetch:
            try:
                predictor = ip1.get_runner(
                    device_target=device_target,
                    dynamic_output_list=[0],
                    device_ids=device_ids,
                )
            except:
                logging.warning("Failed to load model with row fetching.")
                predictor = ip1.get_runner(
                    device_target=device_target,
                    device_ids=device_ids,
                )
                row_fetch = False
        else:
            predictor = ip1.get_runner(
                device_target=device_target,
                device_ids=device_ids,
            )

        # -- static input shapes

        if "Deployer" in mera.__dict__:
            # MERA2
            from mera.deploy_project import CompilationFlow, MeraDeployProject

            prj = MeraDeployProject(Path(path), compile_flow=CompilationFlow.TVM)
        else:
            # MERA1
            from mera.deploy_project import MeraDeployProject

            prj = MeraDeployProject(Path(path))

        json_path = prj.get_artifact("model", "input_desc.json")
        with open(json_path) as jp:
            size_container = json.load(jp)
        assert isinstance(size_container, dict)
        input_info_dt = size_container

        return predictor, input_info_dt, row_fetch

    @classmethod
    def _get_local_model_path(
        cls,
        model_id: Union[str, Path],
        local_dir: Optional[str] = None,
    ):
        model_path = Path(model_id)

        if not model_path.is_dir():
            # try downloading from hub
            from huggingface_hub import snapshot_download

            from_hf_dir = None
            if local_dir and len(local_dir) > 0:
                local_dir = Path(local_dir)
                local_dir.mkdir(parents=True, exist_ok=True)
                model_id = cls._get_sanitized_id(model_id)
                flatten_id = model_id.replace("/", "__")
                from_hf_dir = local_dir.joinpath(flatten_id)

            # TODO: this is a workaround.
            # https://github.com/huggingface/huggingface_hub/issues/1240#issuecomment-1438492986
            # first, download snapshot into cache
            model_path = snapshot_download(repo_id=model_id)

            # then, copy from cache to local_dir
            # with symlink disabled. Else, MERA will throw an error.
            model_path = snapshot_download(
                repo_id=model_id,
                local_dir=from_hf_dir,
                local_dir_use_symlinks=False,
            )

            model_path = Path(model_path)
            if not model_path.is_dir():
                raise NotADirectoryError(
                    f"HF model_path '{model_path}' is not a directory, loading failed."
                )

        # TODO: if not mera config file, throw error for now
        check_file = model_path / _MERA_CONFIG_NAME
        if not check_file.is_file():
            raise FileNotFoundError(f"config file {_MERA_CONFIG_NAME} not found.")

        return model_path

    @classmethod
    def _from_pretrained(
        cls,
        model_id: Union[str, Path],
        config: "PretrainedConfig",
        use_auth_token: Optional[Union[bool, str]] = None,
        revision: Optional[str] = None,
        force_download: bool = False,
        cache_dir: Optional[str] = None,
        file_name: Optional[str] = None,
        subfolder: str = "",
        use_cache: bool = False,
        local_files_only: bool = False,
        use_merged: Optional[bool] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        onnx_name: str = _ONNX_MODEL_NAME,
        target: Tuple = mera.Target.Interpreter,
        device_target: Tuple = mera.mera_deployment.DeviceTarget.SAKURA_1,
        local_dir: str = "./from_hf/",
        measure_latency: bool = False,
        **kwargs,
    ) -> "MERAModel":
        model_path = cls._get_local_model_path(model_id, local_dir)

        # assuming model_path is local path and is in EC deployment format
        # OVERRIDE this class for multi-model loading

        row_fetch = kwargs.get("row_fetch", False)
        deploy_dir = model_path / _MERA_DEPLOYMENT_NAME
        model, input_info_dt, row_fetch = MERAModel.load_model(
            deploy_dir,
            target,
            device_target,
            row_fetch=row_fetch,
        )

        from optimum.utils.save_utils import maybe_load_preprocessors

        onnx_path = model_path
        preprocessors = maybe_load_preprocessors(onnx_path, subfolder=subfolder)

        return cls(
            model=model,
            config=config,
            model_save_dir=model_save_dir,
            preprocessors=preprocessors,
            use_cache=use_cache,
            input_info_dt=input_info_dt,
            measure_latency=measure_latency,
            row_fetch=row_fetch,
        )

    def _save_pretrained(self, save_directory: Union[str, Path]):
        """
        Saves a model and its configuration file to a directory, so that it can be re-loaded using the
        [`MERAModel.from_pretrained`] class method. It will always save the
        file under model_save_dir/latest_model_name.

        Args:
            save_directory (`Union[str, Path]`):
                Directory where to save the model file.
        """
        src_paths = [self.model_path]
        dst_paths = [Path(save_directory) / self.model_path.name]

        # add external data paths in case of large models
        src_paths, dst_paths = _get_external_data_paths(src_paths, dst_paths)

        for src_path, dst_path in zip(src_paths, dst_paths):
            shutil.copyfile(src_path, dst_path)

    @staticmethod
    def _generate_regular_names_for_filename(filename: str):
        name, extension = filename.rsplit(".", maxsplit=1)
        return [
            filename,
            f"{name}_quantized.{extension}",
            f"{name}_optimized.{extension}",
        ]

    def to(self, device):
        # this is for API compatibility, do nothing
        return self

    @classmethod
    def _get_sanitized_id(cls, model_id: str):
        prefixes = [
            "https://huggingface.co/",
            "huggingface.co/",
        ]
        suffixes = [
            "/tree/main",
        ]

        for m in prefixes:
            mlen = len(m)
            if model_id.startswith(m):
                model_id = model_id[mlen:]
        for m in suffixes:
            mlen = len(m)
            if model_id.endswith(m):
                model_id = model_id[:-mlen]

        return model_id

    @classmethod
    def export_from_huggingface(
        cls,
        model_id: str,
        use_auth_token: Optional[Union[bool, str]] = None,
        revision: Optional[str] = None,
        force_download: bool = False,
        cache_dir: Union[str, Path] = "",
        subfolder: str = "",
        local_files_only: bool = False,
        trust_remote_code: bool = False,
        task: Optional[str] = "",
    ) -> "MERAModel":
        if task == "":
            task = cls._auto_model_to_task(cls.auto_model_class)

        model_id = cls._get_sanitized_id(model_id)
        flatten_id = model_id.replace("/", "__")
        flatten_id = Path(str(flatten_id) + "_onnx")  # add suffix

        mera_cache_dir = Path(cache_dir)
        if mera_cache_dir == Path(""):
            # create in .cache instead
            mera_cache_dir = Path.home() / Path(".cache/mera/")

        save_dir_path = mera_cache_dir / flatten_id
        save_dir_path.mkdir(parents=True, exist_ok=True)

        logger.info(f"Exporting onnx from huggingface model_id = '{model_id}'")
        main_export_onnx(
            model_name_or_path=model_id,
            output=save_dir_path,
            task=task,
            do_validation=False,
            no_post_process=True,
            subfolder=subfolder,
            revision=revision,
            cache_dir=None,
            use_auth_token=use_auth_token,
            local_files_only=local_files_only,
            force_download=force_download,
            trust_remote_code=trust_remote_code,
        )
        logger.info(f"Exported to {save_dir_path}")

        return save_dir_path

    @classmethod
    def quantize(
        cls,
        model_id: str,
        out_dir: Union[str, Path],
        platform: Union[str, mera.Platform] = mera.Platform.SAKURA_2C,
        shape_mapping: Dict = {},
        cache_dir: Union[str, Path] = "",
        calib_data: List = [],
        eval_data: List = [],
        qtz_quality_check: bool = False,
        qtz_debug_mode: bool = True,
        apply_smooth_quant: bool = True,
        alpha: float = 0.5,
        autotune: bool = True,
        **kwargs,
    ):
        """quantize HF model. returns .mera file with HF folder structure."""

        platform = get_device_platform(platform)
        qtzed_out_dir = Path(out_dir)
        cache_dir = Path(cache_dir)

        source_onnx_dir = cls._get_source_onnx(model_id=model_id, cache_dir=cache_dir)
        source_onnx_path = source_onnx_dir / _ONNX_MODEL_NAME

        # copy config to new dir (create if necessary)
        cls._copy_config_stuff(source_onnx_dir, qtzed_out_dir)

        # Load model info if it exists...
        model_info = {}
        if (source_onnx_dir / _ONNX_CONFIG_NAME).exists():
            with open(source_onnx_dir / _ONNX_CONFIG_NAME, "r") as r:
                model_info = json.load(r)

        # quantization
        logger.info(f"Using MERA quantizer ...")
        cls._quantize_single_onnx(
            source_onnx_path=source_onnx_path,
            shape_mapping=shape_mapping,
            platform=platform,
            calib_data=calib_data,
            eval_data=eval_data,
            qtzed_path=qtzed_out_dir,
            qtz_quality_check=qtz_quality_check,
            qtz_debug_mode=qtz_debug_mode,
            apply_smooth_quant=apply_smooth_quant,
            alpha=alpha,
            autotune=autotune,
            model_info=model_info,
        )

        return qtzed_out_dir

    @classmethod
    def deploy(
        cls,
        model_id: str,
        out_dir: Union[str, Path],
        host_arch: str = "x86",
        platform: Union[str, mera.Platform] = mera.Platform.SAKURA_2C,
        target: Union[str, mera.Target, List] = mera.Target.Interpreter,
        build_cfg: Dict = {},
        shape_mapping: Dict = {},
        cache_dir: Union[str, Path] = "",
        **kwargs,
    ):
        """Base deployment. might be overridden by task-specific class.

        model_id: can be huggingface model_id or path to onnx file.
        """

        platform = get_device_platform(platform)
        targets = cls._sanitize_targets(target=target)
        out_dir = Path(out_dir)
        cache_dir = Path(cache_dir)
        deploy_dir = out_dir / _MERA_DEPLOYMENT_NAME

        # assumed local dir, quantized .mera file
        source_model_dir = Path(model_id)
        source_model_path = source_model_dir / _QTZED_MERA_MODEL_NAME
        if not source_model_path.is_file():
            # then model_id is either from cloud model_id, or onnx local dir
            source_model_dir = cls._get_source_onnx(
                model_id=model_id, cache_dir=cache_dir
            )
            source_model_path = source_model_dir / _ONNX_MODEL_NAME

        # Load model info if it exists...
        model_info = {}
        if (source_model_dir / _ONNX_CONFIG_NAME).exists():
            with open(source_model_dir / _ONNX_CONFIG_NAME, "r") as r:
                model_info = json.load(r)

        # ----- instantiate the model and save
        logger.info(f"Deploying MERA model ...")

        cls._deploy_single_model(
            source_model_path=source_model_path,
            deploy_dir=deploy_dir,
            shape_mapping=shape_mapping,
            platform=platform,
            build_cfg=build_cfg,
            targets=targets,
            host_arch=host_arch,
            model_info=model_info,
        )

        cls._copy_config_stuff(source_model_dir, out_dir)

        # TODO: fill-in model information
        mera_config_dt = {
            _MERA_DEPLOYMENT_NAME: {"inputs": {}, "outputs": {}},
        }
        cls._save_mera_config(out_dir, mera_config_dt)

        logger.info(f"Complete deployment at {out_dir}")

        return out_dir

    @classmethod
    def _save_mera_config(cls, out_dir, mera_config_dt):
        logger.info(f"Create deployment config {_MERA_CONFIG_NAME}...")

        mera_json_path = out_dir / _MERA_CONFIG_NAME
        with open(mera_json_path, "w") as fp:
            json.dump(mera_config_dt, fp)

        return mera_json_path

    @classmethod
    def _get_source_onnx(cls, model_id, cache_dir, task=""):
        # check if model_id is an onnx file, then
        maybe_path = Path(model_id)
        if maybe_path.is_dir():
            if (maybe_path / _ONNX_MODEL_NAME).is_file():
                return maybe_path
            if (maybe_path / "unet" / _ONNX_MODEL_NAME).is_file():
                # stable diffusion
                return maybe_path
            result = maybe_path.glob("*.onnx")
            for found_onnx in result:
                if found_onnx.is_file():
                    # image-to-text
                    return maybe_path

        source_onnx_dir = cls.export_from_huggingface(
            model_id=model_id,
            cache_dir=cache_dir,
            task=task,
        )

        return source_onnx_dir

    @classmethod
    def _sanitize_targets(cls, target):
        targets = []
        if isinstance(target, List):
            targets = target
        elif isinstance(target, mera.Target):
            targets = [target]
        else:  # assume string with comma as split
            targets = [x.strip() for x in str(target).split(",")]

        # convert to actual mera.Target
        targets = [get_target(tr) for tr in targets]

        return targets

    @classmethod
    def _copy_config_stuff(
        cls,
        source_onnx_dir: Path,
        out_dir: Path,
    ) -> Path:
        logger.info(f"Copy json/txt from {source_onnx_dir} to {out_dir}...")
        files = list(source_onnx_dir.glob("*.json"))
        files += list(source_onnx_dir.glob("*.txt"))
        if len(files) > 0:  # create dir if not exist
            out_dir.mkdir(exist_ok=True)
        for p in files:
            if p.is_file():
                dest = out_dir / p.name
                shutil.copy(p, dest)

        return out_dir

    @classmethod
    def _quantize_single_onnx(
        cls,
        source_onnx_path,
        shape_mapping,
        platform,
        calib_data,
        eval_data,
        qtzed_path=Path("."),
        qtz_quality_check=False,
        qtz_debug_mode=True,
        apply_smooth_quant=True,
        alpha=0.5,
        autotune=True,
        model_info={},
    ):
        if (not calib_data) or (not eval_data):
            raise ValueError("calib_data and eval_data must not be empty.")


        qtzed_save_path, qlty = quantize_with_mera_wrapper(
            source_fp32_path=source_onnx_path,
            shape_mapping=shape_mapping,
            platform=platform,
            calib_data=calib_data,
            eval_data=eval_data,
            qtzed_path=qtzed_path,
            qtz_quality_check=qtz_quality_check,
            qtz_debug_mode=qtz_debug_mode,
            apply_smooth_quant=apply_smooth_quant,
            alpha=alpha,
            autotune=autotune,
            model_info=model_info,
        )

        return qtzed_save_path

    @classmethod
    def _deploy_single_model(
        cls,
        source_model_path,
        deploy_dir,
        shape_mapping,
        platform,
        build_cfg,
        targets,
        host_arch,
        model_info={},
    ):
        # TODO: API here will change once the target is refactored
        is_qtzed_mera = Path(source_model_path).suffix == ".mera"

        # compatibility with MERA1 and MERA2
        if "Deployer" in mera.__dict__:
            deployer_cls = mera.Deployer  # MERA2
        else:
            deployer_cls = mera.TVMDeployer  # MERA1

        with deployer_cls(deploy_dir, overwrite=True) as deployer:
            if is_qtzed_mera:
                model = mera.ModelLoader(deployer).from_quantized_mera(
                    source_model_path,
                )
            else:
                model = mera.ModelLoader(deployer).from_onnx(
                    source_model_path,
                    shape_mapping=shape_mapping,
                    model_info=model_info,
                )

            for tr in targets:
                deployer.deploy(
                    model,
                    mera_platform=platform,
                    build_config=build_cfg,
                    target=tr,
                    host_arch=host_arch,
                )

        return deploy_dir

    @classmethod
    def from_pretrained(
        cls,
        model_id: Union[str, Path],
        export: bool = False,
        force_download: bool = False,
        use_auth_token: Optional[str] = None,
        cache_dir: Optional[str] = None,
        subfolder: str = "",
        config: Optional["PretrainedConfig"] = None,
        local_files_only: bool = False,
        **kwargs,
    ):
        r"""
        Instantiate a pretrained model from a pre-trained model configuration.

        Args:
            model_id (`Union[str, Path]`):
                Can be either:
                    - A string, the *model id* of a pretrained model hosted inside a model repo on huggingface.co.
                        Valid model ids can be located at the root-level, like `bert-base-uncased`, or namespaced under a
                        user or organization name, like `dbmdz/bert-base-german-cased`.
                    - A path to a *directory* containing a model saved using [`~OptimizedModel.save_pretrained`],
                        e.g., `./my_model_directory/`.
            export (`bool`, defaults to `False`):
                Defines whether the provided `model_id` needs to be exported to the targeted format.
            force_download (`bool`, defaults to `True`):
                Whether or not to force the (re-)download of the model weights and configuration files, overriding the
                cached versions if they exist.
            use_auth_token (`Optional[Union[bool,str]]`, defaults to `None`):
                Deprecated. Please use the `token` argument instead.
            cache_dir (`Optional[str]`, defaults to `None`):
                Path to a directory in which a downloaded pretrained model configuration should be cached if the
                standard cache should not be used.
            subfolder (`str`, defaults to `""`):
                In case the relevant files are located inside a subfolder of the model repo either locally or on huggingface.co, you can
                specify the folder name here.
            config (`Optional[transformers.PretrainedConfig]`, defaults to `None`):
                The model configuration.
            local_files_only (`Optional[bool]`, defaults to `False`):
                Whether or not to only look at local files (i.e., do not try to download the model).
        """
        return super().from_pretrained(
            model_id,
            export=export,
            force_download=force_download,
            use_auth_token=use_auth_token,
            cache_dir=cache_dir,
            subfolder=subfolder,
            config=config,
            local_files_only=local_files_only,
            **kwargs,
        )


class MERAModelForImageClassification(MERAModel):
    """
    Mera Model for image-classification tasks.
    """

    auto_model_class = AutoModelForImageClassification

    def forward(
        self,
        pixel_values: Union[torch.Tensor, np.ndarray],
        **kwargs,
    ):
        use_torch = isinstance(pixel_values, torch.Tensor)
        if use_torch:
            pixel_values = pixel_values.cpu().detach().numpy()

        # --- execute inference with MERA
        mera_runner = self.model.set_input(pixel_values).run()
        outputs = mera_runner.get_outputs()
        if self.measure_latency:
            self.measure_estimated_latency(mera_runner)
        logits = outputs[0]
        # ---------------------

        if use_torch:
            logits = torch.tensor(logits).to(self.device)

        # converts output to namedtuple for pipelines post-processing
        return ImageClassifierOutput(logits=logits)


class MERAModelForObjectDetection(MERAModel):
    """
    Mera Model for object-detection tasks.
    """

    auto_model_class = AutoModelForObjectDetection

    @classmethod
    def _overwrite_preprocessor(cls, out_dir, shape_mapping):
        with open(out_dir / "preprocessor_config.json", "r") as file:
            preprocessor_config = json.load(file)
        preprocessor_config["size"] = {
            "height": shape_mapping["height"],
            "width": shape_mapping["width"],
        }
        with open(out_dir / "preprocessor_config.json", "w") as file:
            json.dump(preprocessor_config, file, indent=2)

    @classmethod
    def deploy(
        cls,
        model_id: str,
        out_dir: Union[str, Path],
        host_arch: str = "x86",
        platform: Union[str, mera.Platform] = mera.Platform.SAKURA_2C,
        target: Union[str, mera.Target, List] = mera.Target.Interpreter,
        build_cfg: Dict = {},
        shape_mapping: Dict = {},
        cache_dir: Union[str, Path] = "",
        **kwargs,
    ):
        out_dir = super().deploy(
            model_id=model_id,
            out_dir=out_dir,
            host_arch=host_arch,
            platform=platform,
            target=target,
            build_cfg=build_cfg,
            shape_mapping=shape_mapping,
            cache_dir=cache_dir,
            **kwargs,
        )
        logger.info(f"Overwriting preprocsssor info with shape mapping...")
        cls._overwrite_preprocessor(out_dir, shape_mapping)

    def forward(
        self,
        pixel_values: Union[torch.Tensor, np.ndarray],
        **kwargs,
    ):
        use_torch = isinstance(pixel_values, torch.Tensor)
        if use_torch:
            pixel_values = pixel_values.cpu().detach().numpy()

        # --- execute inference with MERA
        mera_runner = self.model.set_input(pixel_values).run()
        outputs = mera_runner.get_outputs()
        if self.measure_latency:
            self.measure_estimated_latency(mera_runner)
        logits = outputs[0]
        pred_boxes = outputs[1]
        # ---------------------

        if use_torch:
            logits = torch.tensor(logits).to(self.device)
            pred_boxes = torch.tensor(pred_boxes).to(self.device)

        # converts output to namedtuple for pipelines post-processing
        return ObjectDetectionOutput(logits=logits, pred_boxes=pred_boxes)


class MERAModelForSemanticSegmentation(MERAModel):
    """
    Mera Model for semantic-segmentation.
    """

    auto_model_class = AutoModelForSemanticSegmentation

    def forward(self, **kwargs):
        use_torch = isinstance(next(iter(kwargs.values())), torch.Tensor)
        mera_inputs = self._prepare_inputs(use_torch=use_torch, **kwargs)

        # --- execute inference with MERA
        mera_runner = self.model.set_input(mera_inputs).run()
        outputs = mera_runner.get_outputs()
        if self.measure_latency:
            self.measure_estimated_latency(mera_runner)
        logits = outputs[0]
        # ---------------------

        if use_torch:
            logits = torch.tensor(logits).to(self.device)

        # converts output to namedtuple for pipelines post-processing
        return SemanticSegmenterOutput(logits=logits)

    def _prepare_inputs(self, use_torch: bool, **kwargs):
        mera_inputs = {}
        # converts pytorch inputs into numpy inputs for onnx
        for input in self.inputs_names.keys():
            mera_inputs[input] = kwargs.pop(input)

            if use_torch:
                mera_inputs[input] = mera_inputs[input].cpu().detach().numpy()

        return mera_inputs


class MERAModelForSequenceClassification(MERAModel):
    """
    Mera Model with a sequence classification/regression head on top e.g. for GLUE tasks.
    """

    auto_model_class = AutoModelForSequenceClassification

    def forward(
        self,
        input_ids: Optional[Union[torch.Tensor, np.ndarray]] = None,
        attention_mask: Optional[Union[torch.Tensor, np.ndarray]] = None,
        token_type_ids: Optional[Union[torch.Tensor, np.ndarray]] = None,
        **kwargs,
    ):
        use_torch = isinstance(input_ids, torch.Tensor)

        # convert from torch to numpy
        if use_torch:
            input_ids = input_ids.cpu().detach().numpy()
            attention_mask = attention_mask.cpu().detach().numpy()
            if token_type_ids is not None:
                token_type_ids = token_type_ids.cpu().detach().numpy()

        inputs = {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
        }
        if token_type_ids is not None:
            inputs["token_type_ids"] = token_type_ids

        # pad the input
        max_seq = self.input_info_dt["input_ids"][0][1]
        _pad_inputs_for_text_model(inputs, max_seq)

        # --- execute inference with MERA ---
        mera_runner = self.model.set_input(inputs).run()
        outputs = mera_runner.get_outputs()
        if self.measure_latency:
            self.measure_estimated_latency(mera_runner)
        logits = outputs[0]
        # ---------------------

        if use_torch:
            logits = torch.tensor(logits).to(self.device)

        # converts output to namedtuple for pipelines post-processing
        return SequenceClassifierOutput(logits=logits)

    def can_generate(self):
        """Returns False to validate the check that the model using `GenerationMixin.generate()` can indeed generate."""
        return False


class MERAModelForZeroShotImageClassification(MERAModel):
    """
    Mera Model for zero-shot image-classification tasks.
    """

    auto_model_class = AutoModelForZeroShotImageClassification

    def forward(
        self,
        input_ids: Optional[Union[torch.Tensor, np.ndarray]],
        attention_mask: Optional[Union[torch.Tensor, np.ndarray]],
        token_type_ids: Optional[Union[torch.Tensor, np.ndarray]] = None,
        pixel_values: Union[torch.Tensor, np.ndarray] = None,
        **kwargs,
    ):
        use_torch = isinstance(pixel_values, torch.Tensor)
        if use_torch:
            input_ids = input_ids.cpu().detach().numpy()
            attention_mask = attention_mask.cpu().detach().numpy()
            pixel_values = pixel_values.cpu().detach().numpy()
            if token_type_ids is not None:
                token_type_ids = token_type_ids.cpu().detach().numpy()

        inputs = {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
        }
        if token_type_ids is not None:
            inputs["token_type_ids"] = token_type_ids

        # pad the input if needed
        # usually the input_ids will be this shape
        # [num_classes, max_tokens]
        max_seq = self.input_info_dt["input_ids"][0][1]
        _pad_inputs_for_text_model(inputs, max_seq)

        # add pixel value
        inputs["pixel_values"] = pixel_values

        # --- execute inference with MERA
        mera_runner = self.model.set_input(inputs).run()
        outputs = mera_runner.get_outputs()
        if self.measure_latency:
            self.measure_estimated_latency(mera_runner)
        logits = outputs[0]
        # ---------------------

        if use_torch:
            logits = torch.tensor(logits).to(self.device)

        # converts output to namedtuple for pipelines post-processing
        return CLIPOutput(logits_per_image=logits)


class MERAModelForQuestionAnswering(MERAModel):
    """
    Mera Model with a QuestionAnsweringModelOutput for extractive question-answering tasks like SQuAD. This class officially supports albert, bart, bert, camembert, convbert, data2vec_text, deberta, deberta_v2, distilbert, electra, flaubert, gptj, ibert, mbart, mobilebert, nystromformer, roberta, roformer, squeezebert, xlm, xlm_roberta.
    """

    auto_model_class = AutoModelForQuestionAnswering

    def __init__(
        self,
        model: "MERAModel",
        config: "PretrainedConfig",
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        preprocessors: Optional[List] = None,
        **kwargs,
    ):
        super().__init__(model, config, model_save_dir, preprocessors, **kwargs)
        self.output_names = {"start_logits": 0, "end_logits": 1}

    def forward(
        self,
        input_ids: Optional[Union[torch.Tensor, np.ndarray]] = None,
        attention_mask: Optional[Union[torch.Tensor, np.ndarray]] = None,
        token_type_ids: Optional[Union[torch.Tensor, np.ndarray]] = None,
        **kwargs,
    ) -> QuestionAnsweringModelOutput:
        inputs = {}
        input_ids = input_ids.cpu().detach().numpy()
        inputs["input_ids"] = input_ids
        attention_mask = attention_mask.cpu().detach().numpy()
        inputs["attention_mask"] = attention_mask
        if token_type_ids is not None:
            token_type_ids = token_type_ids.cpu().detach().numpy()
            inputs["token_type_ids"] = token_type_ids

        # --- pad/shift the inputs
        cur_seq = inputs["input_ids"].shape[-1]
        max_seq = self.input_info_dt["input_ids"][0][1]
        start = cur_seq - max_seq
        pad_width = ((0, 0), (0, max_seq - cur_seq))
        start_token_id = inputs["input_ids"][0, 0]
        tmp_inputs = {}
        if cur_seq < max_seq:
            # pad
            for k, v in inputs.items():
                inputs[k] = np.pad(
                    v,
                    pad_width=pad_width,
                    mode="constant",
                    constant_values=0,
                )
        elif cur_seq > max_seq:
            # shift
            for k, v in inputs.items():
                tmp_inputs[k] = v.copy()
                inputs[k] = v[:, -max_seq:]

        # --- execute inference with MERA
        inputs_lst = [v for k, v in inputs.items()]
        mera_runner = self.model.set_input(inputs_lst).run()
        outputs = mera_runner.get_outputs()
        if self.measure_latency:
            self.measure_estimated_latency(mera_runner)
        # ---------------------

        # --- unpad/append to complete the outputs
        # TODO: shifting strategy currently does not work
        # it just outputs repeating pattern for some reason
        if cur_seq < max_seq:
            for i, v in enumerate(outputs):
                outputs[i] = v[:, :cur_seq]
        elif cur_seq > max_seq:
            # create longer than max_seq outputs
            for i, v in enumerate(outputs):
                outputs[i] = np.concatenate(
                    (self._prev_outputs[i], v[:, -1:]),
                    axis=1,
                )
            # give back full inputs
            inputs = tmp_inputs
        start_logits = outputs[self.output_names["start_logits"]]
        end_logits = outputs[self.output_names["end_logits"]]

        start_logits = torch.tensor(start_logits).to(self.device)
        end_logits = torch.tensor(end_logits).to(self.device)

        # converts output to namedtuple for pipelines post-processing
        return QuestionAnsweringModelOutput(
            start_logits=start_logits, end_logits=end_logits
        )

    def can_generate(self):
        """Returns False to validate the check that the model using `GenerationMixin.generate()` can indeed generate."""
        return False
