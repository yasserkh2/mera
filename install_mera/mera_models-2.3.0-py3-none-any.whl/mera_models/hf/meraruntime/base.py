# coding=utf-8
# based on Optimum library code
#
"""
Defines the base classes that are used to perform inference with MERA Runtime.
"""

import importlib
import os
import sys
import shutil
from abc import abstractmethod
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Set, Tuple, Union

import numpy as np
import torch
from transformers.modeling_outputs import BaseModelOutput, Seq2SeqLMOutput

from transformers.utils import (
    logging,
)

from .modeling_mera import MERAModel

logger = logging.get_logger(__name__)


class _MERAModelPart:
    """
    For multi-file MERA models, such as encoder-decoder models, represents a part of the model.
    It has its own runtime, and can perform a forward pass.
    """

    CONFIG_NAME = "config.json"

    def __init__(
        self,
        model_path: Path,
        target,
        device_target,
        parent_model: MERAModel,
        **kwargs,
    ):
        self.model_path = model_path
        self.model, self.input_info_dt = MERAModel.load_model(
            model_path, target, device_target
        )
        self.parent_model = parent_model

        config_path = model_path.parent / self.CONFIG_NAME
        self.config = (
            self.parent_model._dict_from_json_file(config_path)
            if config_path.is_file()
            else {}
        )

        self.measure_latency = kwargs.get("measure_latency", False)
        self.estimated_latency = None

    @property
    def device(self):
        return torch.device("cpu")

    @abstractmethod
    def forward(self, *args, **kwargs):
        pass

    def __call__(self, *args, **kwargs):
        return self.forward(*args, **kwargs)
