# coding=utf-8
# based on Optimum library code
#
"""Classes handling seq2seq related architectures in MERA Runtime."""

from abc import ABC, abstractmethod
import copy
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Set, Tuple, Union

from transformers import AutoConfig, PretrainedConfig, add_start_docstrings
from transformers.utils import (
    logging,
)
from transformers import (
    AutoModelForSpeechSeq2Seq,
    GenerationConfig,
)
from transformers.generation.logits_process import WhisperTimeStampLogitsProcessor
from transformers.modeling_outputs import BaseModelOutput, Seq2SeqLMOutput

from optimum.utils import check_if_transformers_greater

import torch
import numpy as np

import mera
from ...utils import get_device_platform, get_device_target, get_target
from .modeling_mera import MERAModel, _ONNX_MODEL_NAME, _MERA_DEPLOYMENT_NAME
from .modeling_decoder import MERAModelForCausalLM
from .base import _MERAModelPart

if check_if_transformers_greater("4.25.0"):
    from transformers.generation import GenerationMixin
else:
    from transformers.generation_utils import GenerationMixin

_ENCODER_FOLDER_NAME = "encoder_model"
_DECODER_FOLDER_NAME = "decoder_model"

logger = logging.get_logger(__name__)


class MERAModelForConditionalGeneration(MERAModel, ABC):
    """
    Sequence-to-sequence model with a language modeling head for MERA Runtime inference.
    """

    def __init__(
        self,
        config: Optional[PretrainedConfig] = None,
        encoder: Optional[MERAModel] = None,
        decoder: Optional[MERAModel] = None,
        generation_config: Optional[GenerationConfig] = None,
        **kwargs,
    ):
        ABC.__init__(self)
        self.device = torch.device("cpu")

        self.config = config

        self.encoder = encoder
        self.decoder = decoder

        # if True:  # DEBUG MODE -- load alternative models
        #     from optimum.onnxruntime import ORTModelForSpeechSeq2Seq
        #     print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        #     print("--- WARNING: DEBUG MODE. WILL RUN SOME MODELS IN ONNX! ---")
        #     print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")

        #     self.onnx_model = ORTModelForSpeechSeq2Seq.from_pretrained(
        #         "./source_model_files/openai__whisper-tiny.en_onnx",
        #         use_cache=False,
        #     )

        #     # Enable encoder onnx to test, MERA has problem running this.
        #     self.encoder = self.onnx_model.encoder

        #     # MERA can run this part, can leave commented out
        #     self.decoder = self.onnx_model.decoder

        if generation_config is None:
            generation_config = GenerationConfig.from_model_config(config)
        self.generation_config = generation_config

    def get_encoder(self):
        return self.encoder

    def get_decoder(self):
        return self.decoder


class MERAModelForSpeechSeq2Seq(MERAModelForConditionalGeneration, GenerationMixin):
    """
    Speech Sequence-to-sequence model with a language modeling head for MERA Runtime inference. This class officially supports whisper, speech_to_text.
    """

    auto_model_class = AutoModelForSpeechSeq2Seq
    main_input_name = "input_features"

    def can_generate(self):
        """Returns True to validate the check that the model using `GenerationMixin.generate()` can indeed generate."""
        return True

    @classmethod
    def _from_pretrained(
        cls,
        model_id: Union[str, Path],
        config: "PretrainedConfig",
        use_auth_token: Optional[Union[bool, str]] = None,
        revision: Optional[str] = None,
        force_download: bool = False,
        cache_dir: Optional[str] = None,
        subfolder: str = "",
        use_cache: bool = True,
        use_merged: Optional[bool] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        target: Tuple = mera.Target.Interpreter,
        device_target: Tuple = mera.mera_deployment.DeviceTarget.SAKURA_1,
        local_dir: str = "./from_hf/",
        measure_latency: bool = False,
        **kwargs,
    ) -> "MERAModel":
        model_path = cls._get_local_model_path(model_id)
        # assuming model_path is local path and is in EC deployment format
        # OVERRIDDEN base class for multi-model loading

        # -- encoder
        model_path = cls._get_local_model_path(model_id, local_dir)
        deploy_dir = model_path / Path(_ENCODER_FOLDER_NAME) / _MERA_DEPLOYMENT_NAME
        encoder = MERAEncoderForSpeech(
            model_path=deploy_dir,
            target=target,
            device_target=device_target,
            parent_model=cls,
        )

        from optimum.utils.save_utils import maybe_load_preprocessors

        onnx_path = model_path
        preprocessors = maybe_load_preprocessors(onnx_path, subfolder="")

        # -- decoder
        deploy_dir = model_path / Path(_DECODER_FOLDER_NAME) / _MERA_DEPLOYMENT_NAME
        decoder_model, input_info_dt = MERAModel.load_model(
            deploy_dir,
            target,
            device_target,
        )

        decoder = MERAModelForCausalLM(
            model=decoder_model,
            config=config,
            model_save_dir=model_save_dir,
            preprocessors=preprocessors,
            use_cache=use_cache,
            input_info_dt=input_info_dt,
            measure_latency=measure_latency,
        )

        generation_config = GenerationConfig.from_pretrained(model_id)

        return cls(
            config,
            encoder=encoder,
            decoder=decoder,
            generation_config=generation_config,
        )

    @classmethod
    def deploy(
        cls,
        model_id: str,
        out_dir: Union[str, Path],
        host_arch: str = "x86",
        platform: Union[str, mera.Platform] = mera.Platform.SAKURA_2C,
        target: Union[str, mera.Target, List] = mera.Target.Interpreter,
        build_cfg: Dict = {},
        shape_mapping: Dict = {},
        cache_dir: Union[str, Path] = "",
        **kwargs,
    ):
        platform = get_device_platform(platform)
        targets = cls._sanitize_targets(target=target)
        out_dir = Path(out_dir)
        cache_dir = Path(cache_dir)

        source_onnx_dir = cls._get_source_onnx(
            model_id=model_id,
            cache_dir=cache_dir,
            task="automatic-speech-recognition",
        )

        logger.info(f"Deploying MERA model ...")

        # -- deploy image encoder
        model_name = _ENCODER_FOLDER_NAME
        cls._deploy_each_model(
            model_name,
            source_onnx_dir,
            out_dir,
            shape_mapping,
            platform,
            build_cfg,
            targets,
            host_arch,
        )

        # -- deploy text decoder
        model_name = _DECODER_FOLDER_NAME
        cls._deploy_each_model(
            model_name,
            source_onnx_dir,
            out_dir,
            shape_mapping,
            platform,
            build_cfg,
            targets,
            host_arch,
        )

        # -- copy other configs
        for fd_name in ["scheduler", "tokenizer", "feature_extractor"]:
            if (source_onnx_dir / fd_name).is_dir():
                cls._copy_config_stuff(source_onnx_dir / fd_name, out_dir / fd_name)

        # -- copy base config
        cls._copy_config_stuff(source_onnx_dir, out_dir)

        # TODO: fill-in model information
        mera_config_dt = {
            _MERA_DEPLOYMENT_NAME: {"inputs": {}, "outputs": {}},
        }
        cls._save_mera_config(out_dir, mera_config_dt)

        logger.info(f"Complete deployment at {out_dir}")

        return out_dir

    @classmethod
    def _deploy_each_model(
        cls,
        model_name,
        source_onnx_dir,
        out_dir,
        shape_mapping,
        platform,
        build_cfg,
        targets,
        host_arch,
    ):
        logger.info(f"Deploying {model_name} ...")

        base_model_dir = out_dir / model_name
        deploy_dir = base_model_dir / _MERA_DEPLOYMENT_NAME
        source_onnx_path = str(source_onnx_dir / model_name) + ".onnx"
        simp_path = str(source_onnx_dir / model_name) + "_simplified.onnx"

        shape_mapping["batch_size"] = shape_mapping.get("batch_size", 1)
        shape_mapping["feature_size"] = shape_mapping.get("feature_size", 80)
        shape_mapping["encoder_sequence_length"] = shape_mapping.get(
            "encoder_sequence_length", 3000
        )
        shape_mapping["decoder_sequence_length"] = shape_mapping.get(
            "decoder_sequence_length", 128
        )

        if model_name == _ENCODER_FOLDER_NAME:
            overwrite_input_shapes = {
                "input_features": [
                    shape_mapping["batch_size"],
                    shape_mapping["feature_size"],
                    shape_mapping["encoder_sequence_length"],
                ]
            }
        else:
            overwrite_input_shapes = {
                "input_ids": [
                    shape_mapping["batch_size"],
                    shape_mapping["decoder_sequence_length"],
                ],
                "encoder_hidden_states": [
                    shape_mapping["batch_size"],
                    shape_mapping["encoder_sequence_length"] // 2,
                    384,
                ],
            }

        # adding this because MERA cannot trace symbolic shape "var_name / 2"
        if not Path(simp_path).is_file():
            cls._apply_onnxsim(source_onnx_path, simp_path, overwrite_input_shapes)

        cls._deploy_single_model(
            source_model_path=simp_path,
            deploy_dir=deploy_dir,
            shape_mapping=shape_mapping,
            platform=platform,
            build_cfg=build_cfg,
            targets=targets,
            host_arch=host_arch,
        )
        cls._copy_config_stuff(source_onnx_dir / model_name, base_model_dir)

        return deploy_dir

    @classmethod
    def _apply_onnxsim(cls, source_onnx_path, simp_path, overwrite_input_shapes):
        import onnx
        from onnxsim import simplify, model_info

        onnx_model = onnx.load(source_onnx_path)
        # convert model
        simp_model, check_ok = simplify(
            model=onnx_model,
            overwrite_input_shapes=overwrite_input_shapes,
        )
        assert check_ok, "something wrong when using onnxsim"

        print("Finish! Here is the difference:")
        model_info.print_simplifying_info(onnx_model, simp_model)
        onnx.save(simp_model, simp_path)

    def forward(
        self,
        input_features: Optional[torch.FloatTensor] = None,
        attention_mask: Optional[torch.LongTensor] = None,
        decoder_input_ids: Optional[torch.LongTensor] = None,
        encoder_outputs: Optional[Tuple[Tuple[torch.Tensor]]] = None,
        past_key_values: Optional[Tuple[Tuple[torch.Tensor]]] = None,
        labels: Optional[torch.LongTensor] = None,
        **kwargs,
    ) -> Seq2SeqLMOutput:
        # Encode if needed : first prediction pass
        if encoder_outputs is None:
            encoder_outputs = self.encoder(input_features=input_features)

        decoder_outputs = self.decoder(
            input_ids=decoder_input_ids,
            past_key_values=past_key_values,
            encoder_hidden_states=encoder_outputs.last_hidden_state,
            encoder_attention_mask=attention_mask,
            labels=labels,
        )

        return Seq2SeqLMOutput(
            loss=decoder_outputs.get("loss", None),
            logits=decoder_outputs.logits,
            past_key_values=decoder_outputs.past_key_values,
        )

    def prepare_inputs_for_generation(
        self,
        input_ids,
        attention_mask=None,
        past_key_values=None,
        head_mask=None,
        decoder_head_mask=None,
        cross_attn_head_mask=None,
        use_cache=None,
        encoder_outputs=None,
        **kwargs,
    ) -> Dict:
        if past_key_values is not None:
            past_length = past_key_values[0][0].shape[2]
            # Some generation methods already pass only the last input ID
            if input_ids.shape[1] > past_length:
                remove_prefix_length = past_length
            else:
                # Default to old behavior: keep only final ID
                remove_prefix_length = input_ids.shape[1] - 1
            input_ids = input_ids[:, remove_prefix_length:]

        return {
            "decoder_input_ids": input_ids,
            "past_key_values": past_key_values,
            "encoder_outputs": encoder_outputs,
            "head_mask": head_mask,
            "decoder_head_mask": decoder_head_mask,
            "cross_attn_head_mask": cross_attn_head_mask,
            "use_cache": use_cache,
        }

    #     @classmethod
    #     def _from_pretrained(
    #         cls,
    #         model_id: Union[str, Path],
    #         config: "PretrainedConfig",
    #         **kwargs,
    #     ):
    #         if "WhisperForConditionalGeneration" in config.architectures:
    #             return _MERAModelForWhisper._from_pretrained(model_id, config, **kwargs)
    #         else:
    #             return super()._from_pretrained(model_id, config, **kwargs)

    # class _MERAModelForWhisper(MERAModelForSpeechSeq2Seq):
    #     """
    #     Whisper implements its own generate() method.
    #     """

    # @classmethod
    # def _from_pretrained(
    #     cls,
    #     model_id: Union[str, Path],
    #     config: "PretrainedConfig",
    #     **kwargs,
    # ):
    #     return super(MERAModelForSpeechSeq2Seq, cls)._from_pretrained(
    #         model_id, config, **kwargs
    #     )

    # Adapted from transformers.models.whisper.modeling_whisper
    def generate(
        self,
        input_features: Optional[torch.Tensor] = None,
        generation_config=None,
        logits_processor=None,
        stopping_criteria=None,
        prefix_allowed_tokens_fn=None,
        synced_gpus=False,
        return_timestamps=None,
        task=None,
        language=None,
        is_multilingual=None,
        prompt_ids: Optional[torch.Tensor] = None,
        num_segment_frames: Optional[int] = None,
        return_token_timestamps: Optional[bool] = None,
        return_segments: bool = False,
        attention_mask: Optional[torch.Tensor] = None,
        time_precision: int = 0.02,
        return_dict_in_generate: Optional[bool] = None,
        **kwargs,
    ):
        if "inputs" in kwargs:
            input_features = kwargs.pop("inputs")
            warnings.warn(
                "The input name `inputs` is deprecated. Please make sure to use `input_features` instead.",
                FutureWarning,
            )

        return_dict_in_generate = (
            return_dict_in_generate
            if return_dict_in_generate is not None
            else self.generation_config.return_dict_in_generate
        )

        if generation_config is None:
            generation_config = copy.deepcopy(self.generation_config)

        # NOTE: replaced from `self.model.encoder.conv1.stride[0] * self.model.encoder.conv2.stride[0]`
        input_stride = 1 * 2
        if num_segment_frames is None:
            # 2 * 1500 = 3000
            num_segment_frames = input_stride * self.config.max_source_positions

        # 1. Check whether we're in shortform or longform mode
        if input_features is not None:
            total_input_frames = input_features.shape[-1]
        elif "encoder_outputs" in kwargs:
            encoder_outputs_shape = (
                kwargs["encoder_outputs"][0].shape
                if isinstance(kwargs["encoder_outputs"], BaseModelOutput)
                else kwargs["encoder_outputs"].shape
            )
            total_input_frames = encoder_outputs_shape[1] * input_stride
        else:
            raise ValueError(
                "Make sure to provide either `input_features` or `encoder_outputs` to `generate`."
            )

        is_shortform = total_input_frames <= num_segment_frames

        # 2. Make sure the generation config is correctly set depending on whether timestamps are to be returned or not
        if return_timestamps is True:
            if not hasattr(generation_config, "no_timestamps_token_id"):
                raise ValueError(
                    "You are trying to return timestamps, but the generation config is not properly set. "
                    "Make sure to initialize the generation config with the correct attributes that are needed such as `no_timestamps_token_id`. "
                    "For more details on how to generate the approtiate config, refer to https://github.com/huggingface/transformers/issues/21878#issuecomment-1451902363"
                )
            generation_config.return_timestamps = return_timestamps
        elif not is_shortform:
            if return_timestamps is False:
                raise ValueError(
                    "You have passed more than 3000 mel input features (> 30 seconds) which automatically enables long-form generation which "
                    "requires the model to predict timestamp tokens. Please either pass `return_timestamps=True` or make sure to pass no more than 3000 mel input features."
                )

            if not hasattr(generation_config, "no_timestamps_token_id"):
                raise ValueError(
                    "You have passed more than 3000 mel input features (> 30 seconds) which automatically enables long-form generation which "
                    "requires the generation config to have `no_timestamps_token_id` correctly. "
                    "Make sure to initialize the generation config with the correct attributes that are needed such as `no_timestamps_token_id`. "
                    "For more details on how to generate the approtiate config, refer to https://github.com/huggingface/transformers/issues/21878#issuecomment-1451902363"
                    "or make sure to pass no more than 3000 mel input features."
                )

            logger.info("Setting `return_timestamps=True` for long-form generation.")
            generation_config.return_timestamps = True
        else:
            generation_config.return_timestamps = False

        # 3. Make sure to correctly set language-related parameters
        if is_multilingual is not None:
            if not hasattr(generation_config, "is_multilingual"):
                raise ValueError(
                    "The generation config is outdated and is thus not compatible with the `is_multilingual` argument "
                    "to `generate`. Please update the generation config as per the instructions "
                    "https://github.com/huggingface/transformers/issues/25084#issuecomment-1664398224"
                )
            generation_config.is_multilingual = is_multilingual

        if (
            hasattr(generation_config, "is_multilingual")
            and not generation_config.is_multilingual
        ):
            if task is not None or language is not None:
                raise ValueError(
                    "Cannot specify `task` or `language` for an English-only model. If the model is intended to be "
                    "multilingual, pass `is_multilingual=True` to generate, or update the generation config."
                )

        if language is not None:
            if not hasattr(generation_config, "lang_to_id"):
                raise ValueError(
                    "The generation config is outdated and is thus not compatible with the `language` argument "
                    "to `generate`. Either set the language using the `forced_decoder_ids` in the model config, "
                    "or update the generation config as per the instructions https://github.com/huggingface/transformers/issues/25084#issuecomment-1664398224"
                )
            language = language.lower()
            generation_config.language = language
        if task is not None:
            if not hasattr(generation_config, "task_to_id"):
                raise ValueError(
                    "The generation config is outdated and is thus not compatible with the `task` argument "
                    "to `generate`. Either set the task using the `forced_decoder_ids` in the model config, "
                    "or update the generation config as per the instructions https://github.com/huggingface/transformers/issues/25084#issuecomment-1664398224"
                )
            generation_config.task = task

        # 4. Add forced decoder ids depending on passed `language`, `task`,`prompt_ids`, `return_token_timestamps` and `return_timestamps`
        forced_decoder_ids = None
        # Legacy code for backward compatibility
        if (
            hasattr(self.config, "forced_decoder_ids")
            and self.config.forced_decoder_ids is not None
        ):
            forced_decoder_ids = self.config.forced_decoder_ids
        elif (
            hasattr(self.generation_config, "forced_decoder_ids")
            and self.generation_config.forced_decoder_ids is not None
        ):
            forced_decoder_ids = self.generation_config.forced_decoder_ids
        else:
            forced_decoder_ids = kwargs.get("forced_decoder_ids", None)

        if (
            task is not None
            or language is not None
            or (forced_decoder_ids is None and prompt_ids is not None)
        ):
            forced_decoder_ids = []
            if hasattr(generation_config, "language"):
                if generation_config.language in generation_config.lang_to_id.keys():
                    language_token = generation_config.language
                elif generation_config.language in TO_LANGUAGE_CODE.keys():
                    language_token = (
                        f"<|{TO_LANGUAGE_CODE[generation_config.language]}|>"
                    )
                elif generation_config.language in TO_LANGUAGE_CODE.values():
                    language_token = f"<|{generation_config.language}|>"
                else:
                    is_language_code = len(generation_config.language) == 2
                    raise ValueError(
                        f"Unsupported language: {generation_config.language}. Language should be one of:"
                        f" {list(TO_LANGUAGE_CODE.values()) if is_language_code else list(TO_LANGUAGE_CODE.keys())}."
                    )
                forced_decoder_ids.append(
                    (1, generation_config.lang_to_id[language_token])
                )
            else:
                forced_decoder_ids.append(
                    (1, None)
                )  # automatically detect the language

            if hasattr(generation_config, "task"):
                if generation_config.task in TASK_IDS:
                    forced_decoder_ids.append(
                        (2, generation_config.task_to_id[generation_config.task])
                    )
                else:
                    raise ValueError(
                        f"The `{generation_config.task}`task is not supported. The task should be one of `{TASK_IDS}`"
                    )
            elif hasattr(generation_config, "task_to_id"):
                forced_decoder_ids.append(
                    (2, generation_config.task_to_id["transcribe"])
                )  # defaults to transcribe
            if (
                hasattr(generation_config, "no_timestamps_token_id")
                and not generation_config.return_timestamps
            ):
                idx = forced_decoder_ids[-1][0] + 1 if forced_decoder_ids else 1
                forced_decoder_ids.append(
                    (idx, generation_config.no_timestamps_token_id)
                )

        if forced_decoder_ids is not None:
            generation_config.forced_decoder_ids = forced_decoder_ids

        if prompt_ids is not None:
            if kwargs.get("decoder_start_token_id") is not None:
                raise ValueError(
                    "When specifying `prompt_ids`, you cannot also specify `decoder_start_token_id` as it gets overwritten."
                )
            prompt_ids = prompt_ids.tolist()
            decoder_start_token_id, *text_prompt_ids = prompt_ids
            # Slicing the text prompt ids in a manner consistent with the OpenAI implementation
            # to accomodate context space for the prefix (see https://github.com/openai/whisper/blob/c09a7ae299c4c34c5839a76380ae407e7d785914/whisper/decoding.py#L599)
            text_prompt_ids = text_prompt_ids[
                -self.config.max_target_positions // 2 - 1 :
            ]
            # Set the decoder_start_token_id to <|startofprev|>
            kwargs.update({"decoder_start_token_id": decoder_start_token_id})

            # If the user passes `max_new_tokens`, increase its number to account for the prompt
            if kwargs.get("max_new_tokens", None) is not None:
                kwargs["max_new_tokens"] += len(text_prompt_ids)
                if kwargs["max_new_tokens"] >= self.config.max_target_positions:
                    raise ValueError(
                        f"The length of the sliced `prompt_ids` is {len(text_prompt_ids)}, and the `max_new_tokens` "
                        f"{kwargs['max_new_tokens'] - len(text_prompt_ids)}. Thus, the combined length of the sliced "
                        f"`prompt_ids` and `max_new_tokens` is: {kwargs['max_new_tokens']}. This exceeds the "
                        f"`max_target_positions` of the Whisper model: {self.config.max_target_positions}. "
                        "You should either reduce the length of your prompt, or reduce the value of `max_new_tokens`, "
                        f"so that their combined length is less that {self.config.max_target_positions}."
                    )

            # Reformat the forced_decoder_ids to incorporate the prompt
            non_prompt_forced_decoder_ids = (
                kwargs.pop("forced_decoder_ids", None)
                or generation_config.forced_decoder_ids
            )
            forced_decoder_ids = [
                *text_prompt_ids,
                generation_config.decoder_start_token_id,
                *[token for _rank, token in non_prompt_forced_decoder_ids],
            ]
            forced_decoder_ids = [
                (rank + 1, token) for rank, token in enumerate(forced_decoder_ids)
            ]
            generation_config.forced_decoder_ids = forced_decoder_ids

        if return_token_timestamps:
            kwargs["output_attentions"] = True
            return_dict_in_generate = True

            if getattr(generation_config, "task", None) == "translate":
                logger.warning(
                    "Token-level timestamps may not be reliable for task 'translate'."
                )
            if not hasattr(generation_config, "alignment_heads"):
                raise ValueError(
                    "Model generation config has no `alignment_heads`, token-level timestamps not available. "
                    "See https://gist.github.com/hollance/42e32852f24243b748ae6bc1f985b13a on how to add this property to the generation config."
                )

            if kwargs.get("num_frames") is not None:
                generation_config.num_frames = kwargs.pop("num_frames")

        if generation_config.return_timestamps is True:
            last_forced_decoder_ids = (
                generation_config.forced_decoder_ids[-1][-1]
                if hasattr(self.config, "forced_decoder_ids")
                and self.config.forced_decoder_ids
                else None
            )
            if last_forced_decoder_ids == self.generation_config.no_timestamps_token_id:
                # remove no_timestamp to be forcefully generated if we want to return timestamps
                # this is also important to make sure `WhisperTimeStampLogitsProcessor` functions correctly
                forced_decoder_ids = generation_config.forced_decoder_ids[:-1]
                # Make sure that if list is empty we set it to None
                generation_config.forced_decoder_ids = (
                    None if len(forced_decoder_ids) == 0 else forced_decoder_ids
                )

            timestamp_processor = [WhisperTimeStampLogitsProcessor(generation_config)]
            logits_processor = (
                timestamp_processor
                if logits_processor is None
                else timestamp_processor + logits_processor
            )

        print(f"is_shortform: {is_shortform}")
        # print(f"input_features: {input_features.shape}")

        # 5. If we're in shortform mode, simple generate the whole input at once and return the output
        if is_shortform:
            outputs = super().generate(
                input_features,
                generation_config,
                logits_processor,
                stopping_criteria,
                prefix_allowed_tokens_fn,
                synced_gpus,
                return_dict_in_generate=return_dict_in_generate,
                **kwargs,
            )

            if return_token_timestamps and hasattr(
                generation_config, "alignment_heads"
            ):
                num_frames = getattr(generation_config, "num_frames", None)
                outputs["token_timestamps"] = self._extract_token_timestamps(
                    outputs, generation_config.alignment_heads, num_frames=num_frames
                )

            return outputs

        # 6. Else we're in longform mode which is more complex.
        # We need to chunk the audio input depending on when the model generated
        # timestamp tokens
        # 6.1 Set running parameters for while loop
        if not return_segments and return_dict_in_generate:
            raise ValueError(
                "Make sure to set `return_segments=True` to return generation outputs as part of the `'segments' key.`"
            )

        # if input is longer than 30 seconds we default to long-form generation
        timestamp_begin = self.generation_config.no_timestamps_token_id + 1
        # input stride is mel frames per encoder output vector
        # which is the product of all conv strides
        batch_size = input_features.shape[0]

        if batch_size > 1 and attention_mask is None:
            raise ValueError(
                "When doing long-form audio transcription, make sure to pass an `attention_mask`. You can retrieve the `attention_mask` by doing `processor(audio, ..., return_attention_mask=True)` "
            )
        elif batch_size > 1:
            max_frames = attention_mask.sum(-1).cpu().to(torch.long)
            seek = torch.zeros((batch_size,), dtype=torch.long)
        else:
            max_frames = torch.ones((1,), dtype=torch.long) * total_input_frames
            seek = torch.zeros((1,), dtype=torch.long)

        current_segments = [[] for _ in range(batch_size)]
        cur_to_prev_index_map = list(range(batch_size))

        # batch size can decrease during the run
        cur_bsz = prev_bsz = batch_size

        # 6.2 Transcribe audio until we reach the end of all input audios
        while (seek < max_frames).any():
            prev_bsz = cur_bsz

            # 6.3 NOTE: When in longform transcription mode and batch size > 1 we need to dynamically reduce the batch size during the loop
            # in case one audio finished earlier than another one. Thus, we need to keep a table of "previous-index-2-current-index" in order
            # to know which original audio is being decoded
            new_cur_to_prev_index_map = []
            for i in range(prev_bsz):
                prev_i = cur_to_prev_index_map[i]
                if seek[prev_i] >= max_frames[prev_i]:
                    cut_index = i + (cur_bsz - prev_bsz)
                    cur_bsz -= 1
                    input_features = torch.cat(
                        [input_features[:cut_index], input_features[cut_index + 1 :]],
                        dim=0,
                    )
                else:
                    # cut out index that goes away
                    new_cur_to_prev_index_map.append(prev_i)

            # 6.4  Set updated index map, duration of previously decoded chunks and number of max frames of current decoding chunk
            cur_to_prev_index_map = new_cur_to_prev_index_map
            time_offset = seek * time_precision / input_stride
            seek_num_frames = (max_frames - seek).clamp(max=num_segment_frames)

            # 6.5 Make sure that all inputs are padded to the same input length
            segment_input = []
            for i in range(cur_bsz):
                prev_i = cur_to_prev_index_map[i]
                segment_input_slice = input_features[
                    i : i + 1, :, seek[prev_i] : seek[prev_i] + seek_num_frames[prev_i]
                ]

                if segment_input_slice.shape[-1] < num_segment_frames:
                    # pad to 3000 if necessary
                    segment_input_slice = torch.nn.functional.pad(
                        segment_input_slice,
                        pad=(0, num_segment_frames - segment_input_slice.shape[-1]),
                    )

                segment_input.append(segment_input_slice)

            segment_input = torch.cat(segment_input, dim=0)

            # 6.6 Batch generate current chunk
            seek_outputs = super().generate(
                segment_input,
                generation_config,
                logits_processor,
                stopping_criteria,
                prefix_allowed_tokens_fn,
                synced_gpus,
                return_dict_in_generate=return_dict_in_generate,
                **kwargs,
            )

            if return_token_timestamps and hasattr(
                generation_config, "alignment_heads"
            ):
                num_frames = getattr(generation_config, "num_frames", None)
                seek_outputs["token_timestamps"] = self._extract_token_timestamps(
                    seek_outputs,
                    generation_config.alignment_heads,
                    num_frames=num_frames,
                )

            if return_dict_in_generate:
                seek_sequences = seek_outputs["sequences"]
                seek_outputs = [
                    {k: v[i] for k, v in seek_outputs.items()}
                    for i in range(next(iter(seek_outputs.values())).size(0))
                ]
            else:
                seek_sequences = seek_outputs

            # 6.7 Loop over each decoded audio individually as each decoding can be of a different length
            for i, seek_sequence in enumerate(seek_sequences):
                prev_i = cur_to_prev_index_map[i]

                # make sure we cut a predicted EOS token if we are not finished with the generation yet
                is_not_final = (seek[prev_i] + num_segment_frames) < max_frames[prev_i]
                if (
                    is_not_final
                    and seek_sequence[-1] == self.generation_config.eos_token_id
                ):
                    seek_sequence = seek_sequence[:-1]

                # remove all padding tokens
                if seek_sequence[-1] == self.generation_config.pad_token_id:
                    num_paddings = (
                        seek_sequence == self.generation_config.pad_token_id
                    ).sum()
                    seek_sequence = seek_sequence[:-num_paddings]

                segments, segment_offset = self._retrieve_segment(
                    seek_sequence=seek_sequence,
                    seek_outputs=seek_outputs,
                    time_offset=time_offset,
                    timestamp_begin=timestamp_begin,
                    seek_num_frames=seek_num_frames,
                    cur_bsz=cur_bsz,
                    time_precision=time_precision,
                    input_stride=input_stride,
                    prev_idx=prev_i,
                    idx=i,
                )

                current_segments[prev_i] += segments
                seek[prev_i] += segment_offset

        # 7. Once all segments are added to the list of all segments, called `current_segments`, we extract the predicted
        # output tokens from the list of dicts. If we use batch size > 1, we make sure to pad the output
        sequences = []
        max_total_length = 0
        for current_segment_list in current_segments:
            sequences.append(
                torch.cat([d["tokens"] for d in current_segment_list], dim=-1)
            )
            max_total_length = max(max_total_length, len(sequences[-1]))

        for i in range(batch_size):
            sequences[i] = torch.nn.functional.pad(
                sequences[i],
                pad=(0, max_total_length - len(sequences[i])),
                value=self.generation_config.pad_token_id,
            )

        sequences = torch.stack(sequences, dim=0)

        # 8. If we return all segments, the predicted output sequences are put under `"sequences"`.
        if return_segments:
            return {"sequences": sequences, "segments": current_segments}

        return sequences

    @staticmethod
    def _retrieve_segment(
        seek_sequence,
        seek_outputs,
        time_offset,
        timestamp_begin,
        seek_num_frames,
        cur_bsz,
        time_precision,
        input_stride,
        prev_idx,
        idx,
    ):
        # find the predicted "end of segment" predictions of Whisper
        # "end of segment" predictions occur whenever Whisper predicts a timestamp token
        timestamp_tokens: torch.Tensor = seek_sequence.ge(timestamp_begin)
        single_timestamp_ending = timestamp_tokens[-2:].tolist() == [False, True]
        timestamp_segment_indices = torch.where(
            timestamp_tokens[:-1] & timestamp_tokens[1:]
        )[0]
        timestamp_segment_indices.add_(1)

        # If whisper predicted a "end of segment" via a timestep token, let's go ever each
        # "end of segment" prediction and slice the decoding into segments accordingly
        if len(timestamp_segment_indices) > 0:
            # if the output contains two consecutive timestamp tokens
            slices = timestamp_segment_indices.tolist()
            segments = []
            if single_timestamp_ending:
                slices.append(len(seek_sequence))

            last_slice = 0
            # Add each segment to list of all segments
            for current_slice in slices:
                sliced_tokens = seek_sequence[last_slice:current_slice]
                start_timestamp_pos = sliced_tokens[0].item() - timestamp_begin
                end_timestamp_pos = sliced_tokens[-1].item() - timestamp_begin
                segments.append(
                    {
                        "start": time_offset[prev_idx]
                        + start_timestamp_pos * time_precision,
                        "end": time_offset[prev_idx]
                        + end_timestamp_pos * time_precision,
                        "tokens": sliced_tokens,
                        "result": seek_outputs[idx],
                    }
                )
                last_slice = current_slice

            if single_timestamp_ending:
                # single timestamp at the end means no speech after the last timestamp.
                segment_offset = seek_num_frames[prev_idx]
            else:
                # otherwise, ignore the unfinished segment and seek to the last timestamp
                # here we throw away all predictions after the last predicted "end of segment"
                # since we are cutting right in the middle of an audio
                last_timestamp_pos = (
                    seek_sequence[last_slice - 1].item() - timestamp_begin
                )
                segment_offset = last_timestamp_pos * input_stride
        else:
            # If whisper does not predict any "end of segment" token, then
            # the whole decoding is considered a segment and we add it to the list of segments
            timestamps = seek_sequence[timestamp_tokens.nonzero().flatten()]
            last_timestamp_pos = seek_num_frames[prev_idx]
            if timestamps.numel() > 0 and timestamps[-1].item() != timestamp_begin:
                # no consecutive timestamps but it has a timestamp; use the last one.
                last_timestamp_pos = timestamps[-1].item() - timestamp_begin

            segments = [
                {
                    "start": time_offset[prev_idx],
                    "end": time_offset[prev_idx] + last_timestamp_pos * time_precision,
                    "tokens": seek_sequence,
                    "result": seek_outputs[idx],
                }
            ]
            segment_offset = seek_num_frames[prev_idx]

        return segments, segment_offset


class MERAEncoderForSpeech(_MERAModelPart):
    """
    Encoder model for MERA Runtime inference for Whisper model.
    """

    main_input_name = "input_features"

    def forward(
        self,
        input_features: np.ndarray,
        **kwargs,
    ) -> BaseModelOutput:
        use_torch = isinstance(input_features, torch.Tensor)

        if use_torch:
            mera_inputs = {"input_features": input_features.cpu().detach().numpy()}
            if "attention_mask" in self.input_info_dt:
                mera_inputs["attention_mask"] = attention_mask.cpu().detach().numpy()
        else:
            mera_inputs = {"input_features": input_features}
            if "attention_mask" in self.input_names:
                mera_inputs["attention_mask"] = attention_mask

        mera_runner = self.model.set_input(mera_inputs).run()
        outputs = mera_runner.get_outputs()
        if self.measure_latency:
            self.measure_estimated_latency(mera_runner)

        last_hidden_state = outputs[0]  # only one output, single batch
        if use_torch:
            last_hidden_state = torch.from_numpy(last_hidden_state).to(self.device)

        return BaseModelOutput(last_hidden_state=last_hidden_state)
