# coding=utf-8
# based on transformers library code
#
"""Classes to support Vision-Encoder-Text-Decoder architectures"""

import gc
import os
import tempfile
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Set, Tuple, Union

import mera
import packaging
import torch
from torch import nn
from torch.nn import CrossEntropyLoss
from transformers import (
    AutoConfig,
    AutoModel,
    AutoModelForCausalLM,
    GenerationConfig,
    PretrainedConfig,
    PreTrainedModel,
)
from transformers.models.vision_encoder_decoder.configuration_vision_encoder_decoder import (
    VisionEncoderDecoderConfig,
)
from transformers.utils import (
    add_start_docstrings,
    add_start_docstrings_to_model_forward,
    logging,
    replace_return_docstrings,
)
from transformers import (
    AutoConfig,
    AutoModel,
    AutoModelForCausalLM,
)
from transformers.models.vision_encoder_decoder.configuration_vision_encoder_decoder import (
    VisionEncoderDecoderConfig,
)
from optimum.utils import check_if_transformers_greater

from ...utils import get_device_platform, get_device_target, get_target
from ..modeling_outputs import BaseModelOutput, Seq2SeqLMOutput
from .modeling_decoder import MERAModelForCausalLM
from .modeling_mera import (
    _MERA_DEPLOYMENT_NAME,
    _ONNX_MODEL_NAME,
    MERAModel,
    MERAModelForImageClassification,
)


if check_if_transformers_greater("4.25.0"):
    from transformers.generation import GenerationMixin
else:
    from transformers.generation_utils import GenerationMixin


_ENCODER_FOLDER_NAME = "encoder_model"
_DECODER_FOLDER_NAME = "decoder_model"

logger = logging.get_logger(__name__)


# Copied from transformers.models.encoder_decoder.modeling_encoder_decoder.shift_tokens_right
def shift_tokens_right(
    input_ids: torch.Tensor, pad_token_id: int, decoder_start_token_id: int
):
    """
    Shift input ids one token to the right.
    """
    shifted_input_ids = input_ids.new_zeros(input_ids.shape)
    shifted_input_ids[:, 1:] = input_ids[:, :-1].clone()
    if decoder_start_token_id is None:
        raise ValueError(
            "Make sure to set the decoder_start_token_id attribute of the model's configuration."
        )
    shifted_input_ids[:, 0] = decoder_start_token_id

    if pad_token_id is None:
        raise ValueError(
            "Make sure to set the pad_token_id attribute of the model's configuration."
        )
    # replace possible -100 values in labels by `pad_token_id`
    shifted_input_ids.masked_fill_(shifted_input_ids == -100, pad_token_id)

    return shifted_input_ids


class MERAVisionEncoderDecoderModel(MERAModel, GenerationMixin):
    r"""
    [`MERAVisionEncoderDecoderModel`] is a MERA  model class that will be instantiated as a transformer architecture with
    one of the base vision model classes of the library as encoder and another one as decoder when created with the
    AutoModel.from_pretrained class method for the encoder and
    AutoModelForCausalLM.from_pretrained class method for the decoder.
    """

    config_class = VisionEncoderDecoderConfig
    base_model_prefix = "vision_encoder_decoder"
    main_input_name = "pixel_values"
    supports_gradient_checkpointing = True

    def __init__(
        self,
        config: Optional[PretrainedConfig] = None,
        encoder: Optional[MERAModel] = None,
        decoder: Optional[MERAModel] = None,
        generation_config: Optional[GenerationConfig] = None,
    ):
        self.device = torch.device("cpu")
        if config is None and (encoder is None or decoder is None):
            raise ValueError(
                "Either a configuration or an encoder and a decoder has to be provided."
            )
        if config is None:
            config = VisionEncoderDecoderConfig.from_encoder_decoder_configs(
                encoder.config, decoder.config
            )
        else:
            if not isinstance(config, self.config_class):
                raise ValueError(
                    f"Config: {config} has to be of type {self.config_class}"
                )

        if config.decoder.cross_attention_hidden_size is not None:
            if config.decoder.cross_attention_hidden_size != config.encoder.hidden_size:
                raise ValueError(
                    "If `cross_attention_hidden_size` is specified in the decoder's configuration, it has to be equal"
                    f" to the encoder's `hidden_size`. Got {config.decoder.cross_attention_hidden_size} for"
                    f" `config.decoder.cross_attention_hidden_size` and {config.encoder.hidden_size} for"
                    " `config.encoder.hidden_size`."
                )
        if generation_config is None:
            generation_config = GenerationConfig.from_model_config(config)
        self.generation_config = generation_config

        # initialize with config
        # make sure input & output embeddings is not tied
        config.tie_word_embeddings = False
        self.config = config

        if encoder is None:
            encoder = AutoModel.from_config(
                config.encoder, attn_implementation=config._attn_implementation
            )

        if decoder is None:
            decoder = AutoModelForCausalLM.from_config(
                config.decoder, attn_implementation=config._attn_implementation
            )

        self.encoder = encoder
        self.decoder = decoder
        self.encoder.main_input_name = "pixel_values"

        if self.encoder.config.to_dict() != self.config.encoder.to_dict():
            logger.warning(
                f"Config of the encoder: {self.encoder.__class__} is overwritten by shared encoder config:"
                f" {self.config.encoder}"
            )
        if self.decoder.config.to_dict() != self.config.decoder.to_dict():
            logger.warning(
                f"Config of the decoder: {self.decoder.__class__} is overwritten by shared decoder config:"
                f" {self.config.decoder}"
            )

        # make sure that the individual model's config refers to the shared config
        # so that the updates to the config will be synced
        self.encoder.config = self.config.encoder
        self.decoder.config = self.config.decoder
        # encoder outputs might need to be projected to different dimension for decoder
        if (
            self.encoder.config.hidden_size != self.decoder.config.hidden_size
            and self.decoder.config.cross_attention_hidden_size is None
        ):
            self.enc_to_dec_proj = nn.Linear(
                self.encoder.config.hidden_size, self.decoder.config.hidden_size
            )

        if self.encoder.get_output_embeddings() is not None:
            raise ValueError(
                f"The encoder {self.encoder} should not have a LM Head. Please use a model without LM Head"
            )

    def get_encoder(self):
        return self.encoder

    def get_decoder(self):
        return self.decoder

    def get_output_embeddings(self):
        return self.decoder.get_output_embeddings()

    def set_output_embeddings(self, new_embeddings):
        return self.decoder.set_output_embeddings(new_embeddings)

    @classmethod
    def deploy(
        cls,
        model_id: str,
        out_dir: Union[str, Path],
        host_arch: str = "x86",
        platform: Union[str, mera.Platform] = mera.Platform.SAKURA_2C,
        target: Union[str, mera.Target, List] = mera.Target.Interpreter,
        build_cfg: Dict = {},
        shape_mapping: Dict = {},
        cache_dir: Union[str, Path] = "",
        **kwargs,
    ):
        platform = get_device_platform(platform)
        targets = cls._sanitize_targets(target=target)
        out_dir = Path(out_dir)
        cache_dir = Path(cache_dir)

        source_onnx_dir = cls._get_source_onnx(
            model_id=model_id, cache_dir=cache_dir, task="image-to-text"
        )

        logger.info(f"Deploying MERA model ...")

        # -- deploy image encoder
        model_name = _ENCODER_FOLDER_NAME
        cls._deploy_each_model(
            model_name,
            source_onnx_dir,
            out_dir,
            shape_mapping,
            platform,
            build_cfg,
            targets,
            host_arch,
        )

        # -- deploy text decoder
        model_name = _DECODER_FOLDER_NAME
        cls._deploy_each_model(
            model_name,
            source_onnx_dir,
            out_dir,
            shape_mapping,
            platform,
            build_cfg,
            targets,
            host_arch,
        )

        # -- copy other configs
        for fd_name in ["scheduler", "tokenizer", "feature_extractor"]:
            if (source_onnx_dir / fd_name).is_dir():
                cls._copy_config_stuff(source_onnx_dir / fd_name, out_dir / fd_name)

        # -- copy base config
        cls._copy_config_stuff(source_onnx_dir, out_dir)

        # TODO: fill-in model information
        mera_config_dt = {
            _MERA_DEPLOYMENT_NAME: {"inputs": {}, "outputs": {}},
        }
        cls._save_mera_config(out_dir, mera_config_dt)

        logger.info(f"Complete deployment at {out_dir}")

        return out_dir

    @classmethod
    def _deploy_each_model(
        cls,
        model_name,
        source_onnx_dir,
        out_dir,
        shape_mapping,
        platform,
        build_cfg,
        targets,
        host_arch,
    ):
        logger.info(f"Deploying {model_name} ...")

        base_model_dir = out_dir / model_name
        deploy_dir = base_model_dir / _MERA_DEPLOYMENT_NAME
        source_onnx_path = str(source_onnx_dir / model_name) + ".onnx"

        cls._deploy_single_model(
            source_model_path=source_onnx_path,
            deploy_dir=deploy_dir,
            shape_mapping=shape_mapping,
            platform=platform,
            build_cfg=build_cfg,
            targets=targets,
            host_arch=host_arch,
        )
        cls._copy_config_stuff(source_onnx_dir / model_name, base_model_dir)

        return deploy_dir

    @classmethod
    def from_pretrained(cls, pretrained_model_name_or_path, *model_args, **kwargs):
        # TODO: write doc API

        # At the moment fast initialization is not supported for composite models
        if kwargs.get("_fast_init", False):
            logger.warning(
                "Fast initialization is currently not supported for MERAVisionEncoderDecoderModel. "
                "Falling back to slow initialization..."
            )
        kwargs["_fast_init"] = False

        return super().from_pretrained(
            pretrained_model_name_or_path, *model_args, **kwargs
        )

    @classmethod
    def _from_pretrained(
        cls,
        model_id: Union[str, Path],
        config: "PretrainedConfig",
        use_auth_token: Optional[Union[bool, str]] = None,
        revision: Optional[str] = None,
        force_download: bool = False,
        cache_dir: Optional[str] = None,
        file_name: Optional[str] = None,
        subfolder: str = "",
        use_cache: bool = False,
        local_files_only: bool = False,
        use_merged: Optional[bool] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        onnx_name: str = _ONNX_MODEL_NAME,
        target: Tuple = mera.Target.Interpreter,
        device_target: Tuple = mera.mera_deployment.DeviceTarget.SAKURA_1,
        local_dir: str = "./from_hf/",
        measure_latency: bool = False,
        **kwargs,
    ) -> "MERAModel":
        model_path = cls._get_local_model_path(model_id)
        # assuming model_path is local path and is in EC deployment format
        # OVERRIDDEN base class for multi-model loading

        # -- encoder
        model_path = cls._get_local_model_path(model_id, local_dir)
        deploy_dir = model_path / Path(_ENCODER_FOLDER_NAME) / _MERA_DEPLOYMENT_NAME
        encoder_model, input_info_dt, row_fetch = MERAModel.load_model(
            deploy_dir,
            target,
            device_target,
        )
        from optimum.utils.save_utils import maybe_load_preprocessors

        onnx_path = model_path
        preprocessors = maybe_load_preprocessors(onnx_path, subfolder="")

        encoder = MERAModelForImageClassification(
            model=encoder_model,
            config=config.encoder,
            model_save_dir=model_save_dir,
            preprocessors=preprocessors,
            use_cache=use_cache,
            input_info_dt=input_info_dt,
            measure_latency=measure_latency,
        )

        # -- decoder
        deploy_dir = model_path / Path(_DECODER_FOLDER_NAME) / _MERA_DEPLOYMENT_NAME
        decoder_model, input_info_dt, row_fetch = MERAModel.load_model(
            deploy_dir,
            target,
            device_target,
        )

        decoder = MERAModelForCausalLM(
            model=decoder_model,
            config=config.decoder,
            model_save_dir=model_save_dir,
            preprocessors=preprocessors,
            use_cache=use_cache,
            input_info_dt=input_info_dt,
            measure_latency=measure_latency,
        )

        return cls(config, encoder=encoder, decoder=decoder)

    @classmethod
    def from_encoder_decoder_pretrained(
        cls,
        model_id: Union[str, Path],
        config: "PretrainedConfig",
        local_dir: str = "./from_hf/",
        encoder_pretrained_model_name_or_path: str = None,
        decoder_pretrained_model_name_or_path: str = None,
        subfolder: str = "",
        target: Tuple = mera.Target.Interpreter,
        device_target: Tuple = mera.mera_deployment.DeviceTarget.SAKURA_1,
        measure_latency: bool = False,
        *model_args,
        **kwargs,
    ) -> PreTrainedModel:
        # this method should take in two model IDs and then later combine them into one model.
        raise NotImplementedError

    def forward(
        self,
        pixel_values: Optional[torch.FloatTensor] = None,
        decoder_input_ids: Optional[torch.LongTensor] = None,
        decoder_attention_mask: Optional[torch.BoolTensor] = None,
        encoder_outputs: Optional[Tuple[torch.FloatTensor]] = None,
        past_key_values: Optional[Tuple[Tuple[torch.FloatTensor]]] = None,
        decoder_inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        **kwargs,
    ) -> Union[Tuple[torch.FloatTensor], Seq2SeqLMOutput]:
        # TODO: doc example to be written
        return_dict = (
            return_dict if return_dict is not None else self.config.use_return_dict
        )

        kwargs_encoder = {
            argument: value
            for argument, value in kwargs.items()
            if not argument.startswith("decoder_")
        }

        kwargs_decoder = {
            argument[len("decoder_") :]: value
            for argument, value in kwargs.items()
            if argument.startswith("decoder_")
        }

        if encoder_outputs is None:
            if pixel_values is None:
                raise ValueError("You have to specify pixel_values")

            encoder_outputs = self.encoder(
                pixel_values=pixel_values,
                output_attentions=output_attentions,
                output_hidden_states=output_hidden_states,
                return_dict=return_dict,
                **kwargs_encoder,
            )
        elif isinstance(encoder_outputs, tuple):
            encoder_outputs = BaseModelOutput(*encoder_outputs)

        encoder_hidden_states = encoder_outputs[0]

        # optionally project encoder_hidden_states
        if (
            self.encoder.config.hidden_size != self.decoder.config.hidden_size
            and self.decoder.config.cross_attention_hidden_size is None
        ):
            encoder_hidden_states = self.enc_to_dec_proj(encoder_hidden_states)

        # else:
        encoder_attention_mask = None

        if (labels is not None) and (
            decoder_input_ids is None and decoder_inputs_embeds is None
        ):
            decoder_input_ids = shift_tokens_right(
                labels, self.config.pad_token_id, self.config.decoder_start_token_id
            )

        # Decode
        decoder_outputs = self.decoder(
            input_ids=decoder_input_ids,
            attention_mask=decoder_attention_mask,
            encoder_hidden_states=encoder_hidden_states,
            encoder_attention_mask=encoder_attention_mask,
            inputs_embeds=decoder_inputs_embeds,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            use_cache=use_cache,
            past_key_values=past_key_values,
            return_dict=return_dict,
            **kwargs_decoder,
        )

        # Compute loss independent from decoder (as some shift the logits inside them)
        loss = None
        if labels is not None:
            logits = decoder_outputs.logits if return_dict else decoder_outputs[0]
            loss_fct = CrossEntropyLoss()
            loss = loss_fct(
                logits.reshape(-1, self.decoder.config.vocab_size), labels.reshape(-1)
            )

        if not return_dict:
            if loss is not None:
                return (loss,) + decoder_outputs + encoder_outputs
            else:
                return decoder_outputs + encoder_outputs

        # cross_attentions is not part of the decoder output, so i removed it.
        return Seq2SeqLMOutput(
            loss=loss,
            logits=decoder_outputs.logits,
            past_key_values=decoder_outputs.past_key_values,
            decoder_hidden_states=decoder_outputs.hidden_states,
            decoder_attentions=decoder_outputs.attentions,
            encoder_last_hidden_state=encoder_outputs.hidden_states,
            encoder_hidden_states=encoder_outputs.hidden_states,
            encoder_attentions=encoder_outputs.attentions,
        )

    def prepare_decoder_input_ids_from_labels(self, labels: torch.Tensor):
        return shift_tokens_right(
            labels, self.config.pad_token_id, self.config.decoder_start_token_id
        )

    def prepare_inputs_for_generation(
        self,
        input_ids,
        past_key_values=None,
        attention_mask=None,
        use_cache=None,
        encoder_outputs=None,
        **kwargs,
    ):
        decoder_inputs = self.decoder.prepare_inputs_for_generation(
            input_ids, past_key_values=past_key_values
        )
        decoder_attention_mask = (
            decoder_inputs["attention_mask"]
            if "attention_mask" in decoder_inputs
            else None
        )
        input_dict = {
            "attention_mask": attention_mask,
            "decoder_attention_mask": decoder_attention_mask,
            "decoder_input_ids": decoder_inputs["input_ids"],
            "encoder_outputs": encoder_outputs,
            "past_key_values": decoder_inputs["past_key_values"],
            "use_cache": use_cache,
        }
        return input_dict

    def resize_token_embeddings(self, *args, **kwargs):
        raise NotImplementedError(
            "Resizing the embedding layers via the MERAVisionEncoderDecoderModel directly is not supported.Please use the"
            " respective methods of the wrapped decoder object (model.decoder.resize_token_embeddings(...))"
        )

    def _reorder_cache(self, past_key_values, beam_idx):
        # apply decoder cache reordering here
        return self.decoder._reorder_cache(past_key_values, beam_idx)

    def can_generate(self):
        """Returns True to validate the check that the model using `GenerationMixin.generate()` can indeed generate."""
        return True
