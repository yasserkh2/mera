#  based on stable-diffusion code from transformers library

import importlib
import logging
import os
import shutil
import sys
from abc import abstractmethod
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Set, Tuple, Union

import mera
import numpy as np
import onnxruntime as ort
import torch
from diffusers import (
    DDIMScheduler,
    LMSDiscreteScheduler,
    PNDMScheduler,
    StableDiffusionPipeline,
    StableDiffusionXLImg2ImgPipeline,
)
from diffusers.schedulers.scheduling_utils import SCHEDULER_CONFIG_NAME
from diffusers.utils import CONFIG_NAME, is_invisible_watermark_available
from huggingface_hub import snapshot_download
from optimum.pipelines.diffusers.pipeline_stable_diffusion import (
    StableDiffusionPipelineMixin,
)
from optimum.pipelines.diffusers.pipeline_utils import VaeImageProcessor
from optimum.utils import (
    DIFFUSION_MODEL_TEXT_ENCODER_2_SUBFOLDER,
    DIFFUSION_MODEL_TEXT_ENCODER_SUBFOLDER,
    DIFFUSION_MODEL_UNET_SUBFOLDER,
    DIFFUSION_MODEL_VAE_DECODER_SUBFOLDER,
    DIFFUSION_MODEL_VAE_ENCODER_SUBFOLDER,
)
from transformers import CLIPFeatureExtractor, CLIPTokenizer
from transformers.file_utils import add_end_docstrings

from ...utils import get_device_platform, get_device_target, get_target
from .modeling_mera import _MERA_DEPLOYMENT_NAME, _ONNX_MODEL_NAME, MERAModel

logger = logging.getLogger(__name__)


class MERAStableDiffusionPipelineBase(MERAModel):
    auto_model_class = StableDiffusionPipeline
    main_input_name = "input_ids"
    config_name = "model_index.json"
    sub_component_config_name = "config.json"

    def __init__(
        self,
        target,
        device_target,
        vae_decoder_path,
        text_encoder_path,
        unet_path,
        config: Dict[str, Any],
        tokenizer: CLIPTokenizer,
        scheduler: Union[DDIMScheduler, PNDMScheduler, LMSDiscreteScheduler],
        feature_extractor: Optional[CLIPFeatureExtractor] = None,
        vae_encoder_path=None,
        text_encoder_2_path=None,
        tokenizer_2: Optional[CLIPTokenizer] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        **kwargs,
    ):
        self._internal_dict = config

        self.vae_decoder = None
        if vae_decoder_path.is_dir():
            self.vae_decoder = MERAModelVaeDecoder(
                vae_decoder_path, target, device_target, self
            )

        self.unet = None
        if unet_path.is_dir():
            self.unet = MERAModelUnet(unet_path, target, device_target, self)

        self.text_encoder = None
        if text_encoder_path.is_dir():
            self.text_encoder = MERAModelTextEncoder(
                text_encoder_path, target, device_target, self
            )

        self.vae_encoder = None
        if vae_encoder_path.is_dir():
            self.vae_encoder = MERAModelVaeEncoder(
                vae_encoder_path, target, device_target, self
            )

        self.text_encoder_2 = None
        if text_encoder_2_path.is_dir():
            self.text_encoder_2 = MERAModelTextEncoder(
                text_encoder_2_path, target, device_target, self
            )

        self.tokenizer = tokenizer
        self.tokenizer_2 = tokenizer_2
        self.scheduler = scheduler
        self.feature_extractor = feature_extractor
        self.safety_checker = None

        sub_models = {
            DIFFUSION_MODEL_TEXT_ENCODER_SUBFOLDER: self.text_encoder,
            DIFFUSION_MODEL_UNET_SUBFOLDER: self.unet,
            DIFFUSION_MODEL_VAE_DECODER_SUBFOLDER: self.vae_decoder,
            DIFFUSION_MODEL_VAE_ENCODER_SUBFOLDER: self.vae_encoder,
            DIFFUSION_MODEL_TEXT_ENCODER_2_SUBFOLDER: self.text_encoder_2,
        }

        # Modify config to keep the resulting model compatible with diffusers pipelines
        for name in sub_models.keys():
            self._internal_dict[name] = (
                ("diffusers", "MERAModel")
                if sub_models[name] is not None
                else (None, None)
            )
        self._internal_dict.pop("vae", None)

        self.vae_scale_factor = 8
        if self.vae_decoder and "block_out_channels" in self.vae_decoder.config:
            self.vae_scale_factor = 2 ** (
                len(self.vae_decoder.config["block_out_channels"]) - 1
            )

        self.image_processor = VaeImageProcessor(vae_scale_factor=self.vae_scale_factor)

    @classmethod
    def _load_config(cls, config_name_or_path: Union[str, os.PathLike], **kwargs):
        return cls.load_config(config_name_or_path, **kwargs)

    def _save_config(self, save_directory):
        self.save_config(save_directory)

    @classmethod
    def deploy(
        cls,
        model_id: str,
        out_dir: Union[str, Path],
        host_arch: str = "x86",
        platform: Union[str, mera.Platform] = mera.Platform.SAKURA_2C,
        target: Union[str, mera.Target, List] = mera.Target.Interpreter,
        build_cfg: Dict = {},
        shape_mapping: Dict = {},
        cache_dir: Union[str, Path] = "",
        **kwargs,
    ):
        platform = get_device_platform(platform)
        targets = cls._sanitize_targets(target=target)
        out_dir = Path(out_dir)
        cache_dir = Path(cache_dir)

        source_onnx_dir = cls._get_source_onnx(model_id=model_id, cache_dir=cache_dir)

        logger.info(f"Deploying MERA model ...")

        # -- deploy text-encoder
        model_name = "text_encoder"
        shape_mapping = {
            "batch_size": 1,
            "sequence_length": 77,
        }

        cls._deploy_each_model(
            model_name,
            source_onnx_dir,
            out_dir,
            shape_mapping,
            platform,
            build_cfg,
            targets,
            host_arch,
        )

        # -- deploy unet
        model_name = "unet"
        shape_mapping = {
            "batch_size": 2,
            "num_channels": 4,
            "height": 64,
            "width": 64,
            "steps": 1,
            "sequence_length": 77,
        }

        cls._deploy_each_model(
            model_name,
            source_onnx_dir,
            out_dir,
            shape_mapping,
            platform,
            build_cfg,
            targets,
            host_arch,
        )

        # -- deploy vae-decoder
        model_name = "vae_decoder"
        shape_mapping = {
            "batch_size": 1,
            "num_channels_latent": 4,
            "height_latent": 64,
            "width_latent": 64,
        }

        cls._deploy_each_model(
            model_name,
            source_onnx_dir,
            out_dir,
            shape_mapping,
            platform,
            build_cfg,
            targets,
            host_arch,
        )

        # -- copy other configs
        for fd_name in ["scheduler", "tokenizer", "feature_extractor"]:
            if (source_onnx_dir / fd_name).is_dir():
                cls._copy_config_stuff(source_onnx_dir / fd_name, out_dir / fd_name)

        # -- copy base config
        cls._copy_config_stuff(source_onnx_dir, out_dir)

        # TODO: fill-in model information
        mera_config_dt = {
            _MERA_DEPLOYMENT_NAME: {"inputs": {}, "outputs": {}},
        }
        cls._save_mera_config(out_dir, mera_config_dt)

        logger.info(f"Complete deployment at {out_dir}")

        return out_dir

    @classmethod
    def _deploy_each_model(
        cls,
        model_name,
        source_onnx_dir,
        out_dir,
        shape_mapping,
        platform,
        build_cfg,
        targets,
        host_arch,
    ):
        logger.info(f"Deploying {model_name} ...")

        base_model_dir = out_dir / model_name
        deploy_dir = base_model_dir / _MERA_DEPLOYMENT_NAME
        source_onnx_path = source_onnx_dir / model_name / _ONNX_MODEL_NAME

        cls._deploy_single_model(
            source_model_path=source_onnx_path,
            deploy_dir=deploy_dir,
            shape_mapping=shape_mapping,
            platform=platform,
            build_cfg=build_cfg,
            targets=targets,
            host_arch=host_arch,
        )
        cls._copy_config_stuff(source_onnx_dir / model_name, base_model_dir)

        return deploy_dir

    @classmethod
    def _from_pretrained(
        cls,
        model_id: Union[str, Path],
        config: "PretrainedConfig",
        use_auth_token: Optional[Union[bool, str]] = None,
        revision: Optional[str] = None,
        force_download: bool = False,
        cache_dir: Optional[str] = None,
        file_name: Optional[str] = None,
        subfolder: str = "",
        use_cache: bool = False,
        local_files_only: bool = False,
        use_merged: Optional[bool] = None,
        model_save_dir: Optional[Union[str, Path, TemporaryDirectory]] = None,
        onnx_name: str = _ONNX_MODEL_NAME,
        target: Tuple = mera.Target.Interpreter,
        device_target: Tuple = mera.mera_deployment.DeviceTarget.SAKURA_1,
        local_dir: str = "./from_hf/",
        measure_latency: bool = False,
        **kwargs,
    ) -> "MERAModel":
        model_path = cls._get_local_model_path(model_id)

        # assuming model_path is local path and is in EC deployment format
        # OVERRIDDEN base class for multi-model loading

        # -- pre/post processing
        patterns = set(config.keys())
        sub_models_to_load = patterns.intersection(
            {"feature_extractor", "tokenizer", "tokenizer_2", "scheduler"}
        )
        new_model_save_dir = model_path
        sub_models = {}
        for name in sub_models_to_load:
            library_name, library_classes = config[name]
            if library_classes is not None:
                library = importlib.import_module(library_name)
                class_obj = getattr(library, library_classes)
                load_method = getattr(class_obj, "from_pretrained")
                # Check if the module is in a subdirectory
                if (new_model_save_dir / name).is_dir():
                    sub_models[name] = load_method(new_model_save_dir / name)
                else:
                    sub_models[name] = load_method(new_model_save_dir)

        # -- load models
        text_encoder_path = model_path / "text_encoder" / _MERA_DEPLOYMENT_NAME
        text_encoder_2_path = model_path / "text_encoder_2" / _MERA_DEPLOYMENT_NAME
        unet_path = model_path / "unet" / _MERA_DEPLOYMENT_NAME
        vae_decoder_path = model_path / "vae_decoder" / _MERA_DEPLOYMENT_NAME
        vae_encoder_path = model_path / "vae_encoder" / _MERA_DEPLOYMENT_NAME

        return cls(
            target=target,
            device_target=device_target,
            unet_path=unet_path,
            vae_decoder_path=vae_decoder_path,
            vae_encoder_path=vae_encoder_path,
            text_encoder_path=text_encoder_path,
            text_encoder_2_path=text_encoder_2_path,
            config=config,
            tokenizer=sub_models.get("tokenizer", None),
            tokenizer_2=sub_models.get("tokenizer_2", None),
            scheduler=sub_models.get("scheduler"),
            feature_extractor=sub_models.get("feature_extractor", None),
            model_save_dir=model_save_dir,
            measure_latency=measure_latency,
        )


class _MERADiffusionModelPart:
    """
    For multi-file MERA models, represents a part of the model.
    It has its own runtime, and can perform a forward pass.
    """

    CONFIG_NAME = "config.json"

    def __init__(
        self, model_path: Path, target, device_target, parent_model: MERAModel
    ):
        self.model_path = model_path
        self.model, input_info_dt, row_fetch = MERAModel.load_model(
            model_path, target, device_target
        )
        self.parent_model = parent_model

        config_path = model_path.parent / self.CONFIG_NAME
        self.config = (
            self.parent_model._dict_from_json_file(config_path)
            if config_path.is_file()
            else {}
        )

        # TODO: (Unet) timestep dtype could change based on models, this needs a more
        # general fix later.
        # https://github.com/huggingface/optimum-graphcore/blob/d415c9e17808b84afb95fbd078175161c85bcfe0/optimum/graphcore/diffusers/pipelines/stable_diffusion/pipeline_stable_diffusion_mixin.py#L175
        self.input_dtype = {"timestep": np.int64}

    @property
    def device(self):
        return torch.device("cpu")

    @abstractmethod
    def forward(self, *args, **kwargs):
        pass

    def __call__(self, *args, **kwargs):
        return self.forward(*args, **kwargs)


class MERAModelTextEncoder(_MERADiffusionModelPart):
    def forward(self, input_ids: np.ndarray):
        mera_inputs = {
            "input_ids": input_ids,
        }

        mera_runner = self.model.set_input(mera_inputs).run()
        outputs = mera_runner.get_outputs()
        if self.measure_latency:
            self.measure_estimated_latency(mera_runner)

        return outputs


class MERAModelUnet(_MERADiffusionModelPart):
    def forward(
        self,
        sample: np.ndarray,
        timestep: np.ndarray,
        encoder_hidden_states: np.ndarray,
        text_embeds: Optional[np.ndarray] = None,
        time_ids: Optional[np.ndarray] = None,
        timestep_cond: Optional[np.ndarray] = None,
    ):
        mera_inputs = {
            "sample": sample,
            "timestep": timestep,
            "encoder_hidden_states": encoder_hidden_states,
        }

        if text_embeds is not None:
            mera_inputs["text_embeds"] = text_embeds

        if time_ids is not None:
            mera_inputs["time_ids"] = time_ids
        if timestep_cond is not None:
            mera_inputs["timestep_cond"] = timestep_cond

        mera_runner = self.model.set_input(mera_inputs).run()
        outputs = mera_runner.get_outputs()
        if self.measure_latency:
            self.measure_estimated_latency(mera_runner)

        return outputs


class MERAModelVaeDecoder(_MERADiffusionModelPart):
    def forward(self, latent_sample: np.ndarray):
        mera_inputs = {
            "latent_sample": latent_sample,
        }

        mera_runner = self.model.set_input(mera_inputs).run()
        outputs = mera_runner.get_outputs()
        if self.measure_latency:
            self.measure_estimated_latency(mera_runner)

        return outputs


class MERAModelVaeEncoder(_MERADiffusionModelPart):
    def forward(self, sample: np.ndarray):
        mera_inputs = {
            "sample": sample,
        }

        mera_runner = self.model.set_input(mera_inputs).run()
        outputs = mera_runner.get_outputs()
        if self.measure_latency:
            self.measure_estimated_latency(mera_runner)

        return outputs


class MERAStableDiffusionPipeline(
    MERAStableDiffusionPipelineBase, StableDiffusionPipelineMixin
):
    """
    MERA Runtime-powered stable diffusion pipeline
    """

    __call__ = StableDiffusionPipelineMixin.__call__
