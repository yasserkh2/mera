# coding=utf-8
# based on Optimum library code
#

from .pipelines_base import (
    MAPPING_LOADING_FUNC,
    MERA_SUPPORTED_TASKS,
    load_mera_pipeline,
    pipeline,
)
