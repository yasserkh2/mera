# coding=utf-8
# based on Optimum library code
#
"""Pipelines running different backends."""

from typing import Any, Dict, Optional, Union

from transformers import (
    AutoConfig,
    AutomaticSpeechRecognitionPipeline,
    Pipeline,
    PreTrainedTokenizer,
    PreTrainedTokenizerFast,
    SequenceFeatureExtractor,
    TextGenerationPipeline,
    ImageClassificationPipeline,
    ImageSegmentationPipeline,
    ImageToTextPipeline,
    TextClassificationPipeline,
    ZeroShotImageClassificationPipeline,
    QuestionAnsweringPipeline,
)
from transformers import pipeline as transformers_pipeline
from transformers.feature_extraction_utils import PreTrainedFeatureExtractor
from transformers.onnx.utils import get_preprocessor
from transformers.pipelines import infer_framework_load_model

from ..meraruntime import (
    MERAModelForCausalLM,
    MERAModelForImageClassification,
    MERAModelForSemanticSegmentation,
    MERAModelForSequenceClassification,
    MERAModelForSpeechSeq2Seq,
    MERAModelForZeroShotImageClassification,
    MERAModelForQuestionAnswering,
    MERAVisionEncoderDecoderModel,
)
from ..meraruntime.modeling_mera import MERAModel

MERA_SUPPORTED_TASKS = {
    "text-generation": {
        "impl": TextGenerationPipeline,
        "class": (MERAModelForCausalLM,),
        "default": "distilgpt2",
        "type": "text",
    },
    "image-classification": {
        "impl": ImageClassificationPipeline,
        "class": (MERAModelForImageClassification,),
        "default": "google/vit-base-patch16-224",
        "type": "image",
    },
    "image-to-text": {
        "impl": ImageToTextPipeline,
        "class": (MERAVisionEncoderDecoderModel,),
        "default": "nlpconnect/vit-gpt2-image-captioning",
        "type": "multimodal",
    },
    "image-segmentation": {
        "impl": ImageSegmentationPipeline,
        "class": (MERAModelForSemanticSegmentation,),
        "default": "nvidia/segformer-b0-finetuned-ade-512-512",
        "type": "image",
    },
    "text-classification": {
        "impl": TextClassificationPipeline,
        "class": (MERAModelForSequenceClassification,),
        "default": "distilbert-base-uncased-finetuned-sst-2-english",
        "type": "text",
    },
    "question-answering": {
        "impl": QuestionAnsweringPipeline,
        "class": (MERAModelForQuestionAnswering,),
        "default": "deepset/roberta-base-squad2",
        "type": "text",
    },
    "zero-shot-image-classification": {
        "impl": ZeroShotImageClassificationPipeline,
        "class": (MERAModelForZeroShotImageClassification,),
        "default": "hf-internal-testing/tiny-random-clip-zero-shot-image-classification",
        "type": "multimodal",
    },
    "automatic-speech-recognition": {
        "impl": AutomaticSpeechRecognitionPipeline,
        "class": (MERAModelForSpeechSeq2Seq,),
        "default": "openai/whisper-tiny.en",
        "type": "multimodal",
    },
}


def load_mera_pipeline(
    model,
    targeted_task,
    load_tokenizer,
    tokenizer,
    feature_extractor,
    load_feature_extractor,
    SUPPORTED_TASKS,
    subfolder: str = "",
    token: Optional[Union[bool, str]] = None,
    revision: str = "main",
    model_kwargs: Optional[Dict[str, Any]] = {},
    config: AutoConfig = None,
    **kwargs,
):
    if isinstance(model, str):
        raise NotImplementedError("loading model from string not supported yet")
    elif isinstance(model, MERAModel):
        if tokenizer is None and load_tokenizer:
            for preprocessor in model.preprocessors:
                if isinstance(
                    preprocessor, (PreTrainedTokenizer, PreTrainedTokenizerFast)
                ):
                    tokenizer = preprocessor
                    break
            if tokenizer is None:
                raise ValueError(
                    "Could not automatically find a tokenizer for the MERAModel, you must pass a tokenizer explictly"
                )
        if feature_extractor is None and load_feature_extractor:
            for preprocessor in model.preprocessors:
                if isinstance(preprocessor, SequenceFeatureExtractor):
                    feature_extractor = preprocessor
                    break
            if feature_extractor is None:
                raise ValueError(
                    "Could not automatically find a feature extractor for the MERAModel, you must pass a "
                    "feature_extractor explictly"
                )
        model_id = None
    else:
        raise ValueError(
            f"""Model {model} is not supported. Please provide a valid model as string or MERAModel.
            """
        )
    return model, model_id, tokenizer, feature_extractor


MAPPING_LOADING_FUNC = {
    "mera": load_mera_pipeline,
}


def pipeline(
    task: str = None,
    model: Optional[Any] = None,
    tokenizer: Optional[Union[str, PreTrainedTokenizer]] = None,
    feature_extractor: Optional[Union[str, PreTrainedFeatureExtractor]] = None,
    use_fast: bool = True,
    token: Optional[Union[str, bool]] = None,
    accelerator: Optional[str] = "mera",
    revision: Optional[str] = None,
    trust_remote_code: Optional[bool] = None,
    *model_kwargs,
    **kwargs,
) -> Pipeline:
    targeted_task = "translation" if task.startswith("translation") else task
    if accelerator == "mera":
        if targeted_task not in list(MERA_SUPPORTED_TASKS.keys()):
            raise ValueError(
                f"Task {targeted_task} is not supported for the MERA Runtime pipeline. Supported tasks are { list(MERA_SUPPORTED_TASKS.keys())}"
            )

    if accelerator not in MAPPING_LOADING_FUNC:
        raise ValueError(
            f'Accelerator {accelerator} is not supported. Supported accelerator is "mera".'
        )

    # copied from transformers.pipelines.__init__.py
    hub_kwargs = {
        "revision": revision,
        "token": token,
        "trust_remote_code": trust_remote_code,
        "_commit_hash": None,
    }

    config = kwargs.get("config", None)
    # if config is None and isinstance(model, str):
    #     config = AutoConfig.from_pretrained(
    #         model, _from_pipeline=task, **hub_kwargs, **kwargs
    #     )
    #     hub_kwargs["_commit_hash"] = config._commit_hash

    supported_tasks = MERA_SUPPORTED_TASKS

    no_feature_extractor_tasks = set()
    no_tokenizer_tasks = set()
    for _task, values in supported_tasks.items():
        if values["type"] == "text":
            no_feature_extractor_tasks.add(_task)
        elif values["type"] in {"image", "video"}:
            no_tokenizer_tasks.add(_task)
        elif values["type"] in {"audio"}:
            no_tokenizer_tasks.add(_task)
        elif values["type"] not in ["multimodal", "audio", "video"]:
            raise ValueError(
                f"SUPPORTED_TASK {_task} contains invalid type {values['type']}"
            )

    # copied from transformers.pipelines.__init__.py l.609
    if targeted_task in no_tokenizer_tasks:
        # These will never require a tokenizer.
        # the model on the other hand might have a tokenizer, but
        # the files could be missing from the hub, instead of failing
        # on such repos, we just force to not load it.
        load_tokenizer = False
    else:
        load_tokenizer = True

    if targeted_task in no_feature_extractor_tasks:
        load_feature_extractor = False
    else:
        load_feature_extractor = True

    model, model_id, tokenizer, feature_extractor = MAPPING_LOADING_FUNC[accelerator](
        model,
        targeted_task,
        load_tokenizer,
        tokenizer,
        feature_extractor,
        load_feature_extractor,
        SUPPORTED_TASKS=supported_tasks,
        config=config,
        hub_kwargs=hub_kwargs,
        token=token,
        *model_kwargs,
        **kwargs,
    )

    if tokenizer is None and load_tokenizer:
        tokenizer = get_preprocessor(model_id)
    if feature_extractor is None and load_feature_extractor:
        feature_extractor = get_preprocessor(model_id)

    return transformers_pipeline(
        task,
        model=model,
        tokenizer=tokenizer,
        feature_extractor=feature_extractor,
        use_fast=use_fast,
        device="cpu",  # TODO: force cpu for now
        **kwargs,
    )
