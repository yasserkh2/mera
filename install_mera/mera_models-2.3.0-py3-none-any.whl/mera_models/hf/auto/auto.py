from ..meraruntime.modeling_mera import (
    MERAModelForImageClassification,
    MERAModelForSemanticSegmentation,
    MERAModelForSequenceClassification,
    MERAModelForZeroShotImageClassification,
    MERAModelForQuestionAnswering,
)

from ..meraruntime.modeling_decoder import (
    MERAModelForCausalLM,
)

from ..meraruntime.modeling_seq2seq import (
    MERAModelForSpeechSeq2Seq,
)

from ..meraruntime.modeling_vision_encoder_decoder import (
    MERAVisionEncoderDecoderModel,
)

from optimum.onnxruntime import (
    ORTModelForImageClassification,
    ORTModelForSemanticSegmentation,
    ORTModelForSequenceClassification,
    ORTModelForSpeechSeq2Seq,
    ORTModelForQuestionAnswering,
    ORTModelForCausalLM,
    ORTModelForVision2Seq,
)

from transformers import (
    AutoModelForImageClassification,
    AutoModelForSemanticSegmentation,
    AutoModelForSequenceClassification,
    AutoModelForSpeechSeq2Seq,
    AutoModelForZeroShotImageClassification,
    AutoModelForQuestionAnswering,
    AutoModelForCausalLM,
    AutoModelForVision2Seq,
)

RUNTIME_TASK_MAPPING = {
    "mera": {
        "image-classification": MERAModelForImageClassification,
        "question-answering": MERAModelForQuestionAnswering,
        "text-classification": MERAModelForSequenceClassification,
        "text-generation": MERAModelForCausalLM,
        "image-to-text": MERAVisionEncoderDecoderModel,
        "automatic-speech-recognition": MERAModelForSpeechSeq2Seq,
    },
    "onnx": {
        "image-classification": ORTModelForImageClassification,
        "question-answering": ORTModelForQuestionAnswering,
        "text-classification": ORTModelForSequenceClassification,
        "text-generation": ORTModelForCausalLM,
        "image-to-text": ORTModelForVision2Seq,
        "automatic-speech-recognition": ORTModelForSpeechSeq2Seq,
    },
    "huggingface": {
        "image-classification": AutoModelForImageClassification,
        "question-answering": AutoModelForQuestionAnswering,
        "text-classification": AutoModelForSequenceClassification,
        "text-generation": AutoModelForCausalLM,
        "image-to-text": AutoModelForVision2Seq,
        "automatic-speech-recognition": AutoModelForSpeechSeq2Seq,
    },
}


def load_auto_model(model_id, runtime="mera", task="text-classification", **kwargs):
    # sanity check input variables
    if runtime not in RUNTIME_TASK_MAPPING.keys():
        ValueError(f"runtime '{runtime}' requested not available.")
        if task not in RUNTIME_TASK_MAPPING[runtime].keys():
            ValueError(
                f"task '{task}' requested not available for runtime '{runtime}'."
            )

    # get class
    mf = RUNTIME_TASK_MAPPING[runtime][task]

    if runtime == "mera":
        model = mf.from_pretrained(
            model_id,
            use_cache=False,
            target=kwargs.get("target", "Interpreter"),
            device_target=kwargs.get("device_target", "sakura1"),
            measure_latency=True,
            device_id=kwargs.get("device_id", None),
        )
    elif runtime == "onnx":  # cpu
        model = mf.from_pretrained(
            model_id,
            use_cache=False,
            use_io_binding=False,
        )
    else:  # torch/tf GPU/CPU
        model = mf.from_pretrained(model_id)

    return model


def load_auto_pipeline(runtime="mera"):
    if runtime not in RUNTIME_TASK_MAPPING.keys():
        ValueError(f"runtime '{runtime}' requested not available.")

    if runtime == "mera":
        from ..pipelines import pipeline

        return pipeline
    elif runtime == "onnx":
        from optimum.pipelines import pipeline

        return pipeline
    else:
        from transformers import pipeline

        return pipeline
