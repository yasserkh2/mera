import torch
from dataclasses import dataclass
from transformers.modeling_outputs import (
    ModelOutput,
    BaseModelOutput,
    CausalLMOutput,
    CausalLMOutputWithPast,
    ImageClassifierOutput,
    MaskedLMOutput,
    MultipleChoiceModelOutput,
    QuestionAnsweringModelOutput,
    SemanticSegmenterOutput,
    SequenceClassifierOutput,
    TokenClassifierOutput,
    XVectorOutput,
    Seq2SeqLMOutput,
)


@dataclass
class ObjectDetectionOutput(ModelOutput):
    logits: torch.FloatTensor = None
    pred_boxes: torch.FloatTensor = None
