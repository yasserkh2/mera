import textwrap
from pathlib import Path
import sys
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Set, Tuple, Union
import json

import cv2
import numpy as np

import mera
import json

_QTZED_MERA_MODEL_NAME = "model.mera"
_QTZED_MERA_MODEL_QPARAM_NAME = "q_params.json"
_QTZED_MERA_DEPLOY_DIR = "qtzer_deploy"


def draw_outlined_text(
    image,
    txt,
    txt_x,
    txt_y,
    font=cv2.FONT_HERSHEY_SIMPLEX,
    font_scale=0.6,
    thick=4,
    c_in=(255, 255, 255),
    c_out=(0, 0, 0),
):
    # outline
    cv2.putText(image, txt, (txt_x, txt_y), font, font_scale, c_out, thick, cv2.LINE_AA)
    # core
    thick_in = max(1, thick // 4)
    cv2.putText(
        image, txt, (txt_x, txt_y), font, font_scale, c_in, thick_in, cv2.LINE_AA
    )


def draw_paragraph(
    image,
    paragraph,
    txt_x=30,
    txt_y=30,
    line_spacing=30,
    font_scale=0.6,
    thick=4,
):
    for line in paragraph:
        draw_outlined_text(
            image, line, txt_x, txt_y, font_scale=font_scale, thick=thick
        )
        txt_y += line_spacing


def draw_text_as_overlay(
    text,
    overlay,
    max_char_per_line,
    font_scale,
    thick=4,
    font=cv2.FONT_HERSHEY_SIMPLEX,
    line_spacing_scale=1.2,
):
    # get text height measurement
    example = "asdf"
    (w, h), baseline = cv2.getTextSize(example, font, font_scale, thick)
    txt_h = h + baseline
    line_sp = int(txt_h * line_spacing_scale)

    # make a paragraph
    para = textwrap.wrap(text, width=max_char_per_line)

    # create overlay
    if overlay is None:
        line_num = len(para)
        min_height = max(600, int(line_num * (txt_h + line_sp / 4)))
        min_width = 600
        overlay = np.zeros((min_height, min_width, 3), dtype=np.uint8)

    # draw actual texts
    draw_paragraph(
        overlay,
        para,
        txt_x=txt_h,
        txt_y=txt_h,
        line_spacing=line_sp,
        font_scale=font_scale,
    )

    return overlay


def save_text_as_image_file(
    save_path,
    txt,
    overlay=None,
    max_char_per_line=50,
    font_scale=0.6,
    thick=4,
    font=cv2.FONT_HERSHEY_SIMPLEX,
    line_spacing_scale=1.2,
):
    cv2.imwrite(
        save_path,
        draw_text_as_overlay(
            txt,
            overlay,
            max_char_per_line,
            font_scale,
            thick,
            font,
            line_spacing_scale,
        ),
    )


def get_device_target(device_str):
    from mera.mera_deployment import DeviceTarget

    if isinstance(device_str, DeviceTarget):
        return device_str

    dt = {str(e.value[0]).lower(): e for e in DeviceTarget}
    dt.update(
        {
            "intel": DeviceTarget.INTEL_IA420,
            "xilinx": DeviceTarget.XILINX_U50,
            "sakura1": DeviceTarget.SAKURA_1,
            "sakura_1": DeviceTarget.SAKURA_1,
        }
    )

    try:
        new_enum = DeviceTarget.SAKURA_2
    except:
        new_enum = DeviceTarget.SAKURA_1
    dt.update({"sakura2": new_enum})

    if device_str.lower() not in dt:
        raise ValueError(
            f"{device_str} is not supported. Available choices are {list(dt.keys())}."
        )
    return dt[device_str]


def get_device_platform(device_str):
    from mera import Platform

    if isinstance(device_str, Platform):
        return device_str

    dt = {str(e.value).lower(): e for e in Platform}
    dt.update(
        {
            "sakura1": Platform.SAKURA_1,
            "sakura_1": Platform.SAKURA_1,
            "sakura2": Platform.SAKURA_2C,
            "sakura_2": Platform.SAKURA_2C,
            "sakura_2c": Platform.SAKURA_2C,
        }
    )

    if device_str.lower() not in dt:
        raise ValueError(
            f"{device_str} is not supported. Available choices are {list(dt.keys())}."
        )
    return dt[device_str]


def get_target(target_str):
    from mera import Target

    if isinstance(target_str, Target):
        return target_str

    # str -> enum obj
    dt = {str(e.value[0]).lower(): e for e in Target}
    dt["cpu"] = Target.Interpreter
    dt["bf16"] = Target.InterpreterBf16
    if target_str.lower() not in dt:
        raise ValueError(
            f"{target_str} is not supported. Available choices are {list(dt.keys())}."
        )
    return dt[target_str.lower()]


def flags_to_dict(flags):
    dt = {}
    for word in flags.split(","):
        k, v = word.split("=")
        dt[k.strip()] = v.strip()
    return dt


def quantize_with_mera_wrapper(
    source_fp32_path,
    shape_mapping,
    platform,
    calib_data,
    eval_data=[],
    qtzed_path=Path("./qtzed_tmp"),
    qtzed_model_name=_QTZED_MERA_MODEL_NAME,
    qtzed_model_qparam_name=_QTZED_MERA_MODEL_QPARAM_NAME,
    qtzed_deploy_dir=_QTZED_MERA_DEPLOY_DIR,
    qtz_quality_check=True,
    qtz_debug_mode=False,
    apply_smooth_quant=False,
    alpha=0.5,
    autotune=True,
    model_info={},
    **kwargs,
):
    """wrapper function for mera quantizer, for convenient usage and backward compatibility"""
    import mera

    platform = get_device_platform(platform)

    qtzed_path = Path(qtzed_path).resolve()
    if qtzed_path == Path(".").resolve() or qtzed_path.name == "model.mera":
        raise ValueError(
            "qtzed_path should be a folder, not current directory or 'model.mera'"
        )

    if not calib_data:
        raise ValueError("calib_data must not be empty.")

    if qtz_quality_check and not eval_data:
        raise ValueError("with qtz_quality_check = True, eval_data must not be empty.")

    is_qtzer_v2 = hasattr(mera, "Quantizer")

    if isinstance(calib_data[0], dict):
        input_desc = {
            k: (tuple(v.shape), str(v.dtype)) for k, v in calib_data[0].items()
        }
        input_shape = [tuple(v.shape) for v in calib_data[0].values()]
        input_types = [v.dtype for v in calib_data[0].values()]
    else:
        if is_qtzer_v2:
            raise ValueError(
                "quantizer needs calib data in a form of [{'input_name', data}]"
            )
        input_desc = {}  # for completeness sake
        input_shape = [tuple(v.shape) for v in calib_data[0]]
        input_types = [v.dtype for v in calib_data[0]]

    qlty = None  # dummy quality score obj
    qtzed_save_path = qtzed_path / qtzed_model_name
    fp32_suffix = Path(source_fp32_path).suffix
    check2 = fp32_suffix == ".onnx"

    if is_qtzer_v2 and check2:
        # --- quantizer_v2 API must have mera.Quantizer class

        # NOTE We support caching of the conversion for quantizer, but we need to be sure
        # we are actually quantizing the same model! This is TODO.
        with mera.Deployer(
            qtzed_path / _QTZED_MERA_DEPLOY_DIR, overwrite=True
        ) as deployer:
            if fp32_suffix == ".onnx":
                # working
                model_fp32 = mera.ModelLoader(deployer).from_onnx(
                    source_fp32_path, shape_mapping=shape_mapping, model_info=model_info
                )
            elif fp32_suffix == ".tflite":
                # still TODO
                model_fp32 = mera.ModelLoader(deployer).from_tflite(source_fp32_path)
            else:  # assume torchscript
                # still TODO
                model_fp32 = mera.ModelLoader(deployer).from_pytorch(
                    source_fp32_path,
                    input_desc=input_desc,
                    layout=mera.Layout.NCHW,
                )

            qtzer_cfg = mera.quantizer.QuantizerConfigPresets.DNA_SAKURA_II
            qtzer = mera.Quantizer(
                deployer, model_fp32, quantizer_config=qtzer_cfg, mera_platform=platform
            )
            if apply_smooth_quant:
                qtzer.calibrate(calib_data).apply_smoothquant(
                    alpha=alpha, autotune=autotune
                )

            model_qtz = qtzer.calibrate(calib_data).quantize()
            model_qtz.save_to(qtzed_save_path)
            if qtz_quality_check:
                qlty = qtzer.evaluate_quality(eval_data)
            # Save quantization report. TODO id should be an identifier of the build.
            report_id = qtzed_path.name
            with open(qtzed_path / "qtz_report.json", "w") as w:
                w.write(json.dumps(qtzer.get_report(report_id), indent=4))
    else:
        # --- fall back to quantizer_v1 API
        qtzed_path.mkdir(parents=True, exist_ok=True)
        if fp32_suffix == ".onnx":
            model_qtz = mera.ModelQuantizer(
                source_fp32_path,
                input_shape=input_shape,
                shape_mapping=shape_mapping,
                mera_platform=platform,
                input_types=input_types,
                quantization_directory=qtzed_path / qtzed_deploy_dir,
                model_info=model_info,
                layout=mera.Layout.NCHW,
            )
            if apply_smooth_quant:
                model_qtz.calibrate(calib_data).apply_smoothquant(
                    alpha=alpha, autotune=autotune
                )
        else:  # assume pytorch
            model_qtz = mera.ModelQuantizer(
                source_fp32_path,
                input_shape=input_shape,
                mera_platform=platform,
                # input_types=input_types,
                # quantization_directory=qtzed_path / qtzed_deploy_dir,
                layout=mera.Layout.NCHW,
            )
            # change data from dict to tuple
            calib_data = [tuple(dt.values()) for dt in calib_data]
            if eval_data:
                eval_data = [tuple(dt.values()) for dt in eval_data]

        qtz = model_qtz.calibrate(calib_data).quantize()

        qtz.save_qtz_parameters(qtzed_path / qtzed_model_qparam_name)
        qtz.save(qtzed_save_path)

        if qtz_quality_check:
            qlty = qtz.measure_quantization_quality(
                eval_data, debug_mode=qtz_debug_mode
            )

            if qtz_debug_mode:
                # this will dump qtz data to `qtz_debug_metrics.json`
                qlty.summary()

    return qtzed_save_path, qlty


def _sanitize_source_model_path(orig_model_path):
    # assumed local dir, quantized .mera file
    source_model_path = Path(orig_model_path).resolve()  # make abs path

    if not source_model_path.exists():
        raise ValueError(f"source model path does not exist. {source_model_path}")

    if source_model_path.is_dir():
        mera_files = list(source_model_path.glob("*.mera"))
        if not mera_files:
            raise ValueError(
                f"source model path is a dir and no .mera file exists. {source_model_path}"
            )
        source_model_path = Path(mera_files[0]).resolve()

    # is a file at this point
    compatible_suffixes = [".onnx", ".tflite", ".pt", ".torchscript", ".mera"]
    if not source_model_path.suffix in compatible_suffixes:
        raise ValueError(
            f"""
            source model file extension is not compatible with mera deployer.
            compatible exts are {compatible_suffixes}
            path is {source_model_path}
            """
        )

    return source_model_path


def _sanitize_targets(target):
    targets = []
    if isinstance(target, List):
        targets = target
    elif isinstance(target, mera.Target):
        targets = [target]
    else:  # assume string with comma as split
        targets = [x.strip() for x in str(target).split(",")]

    # convert to actual mera.Target
    targets = [get_target(tr) for tr in targets]

    return targets


def get_model_loaded_with_mera(
    deployer,  # Deployer or TVMDeployer
    source_model_path: Union[str, Path],
    shape_mapping: Dict = {},
    model_info: Dict = {},
    input_desc: Dict[str, tuple] = {"_empty": ((1, 3, 640, 640), "float32")},
    layout: mera.Layout = mera.Layout.NCHW,
    **kwargs,
):
    if source_model_path.suffix == ".mera":
        try:
            model = mera.ModelLoader(deployer).from_quantized_mera(
                source_model_path,
            )
        except RuntimeError as e:
            error_message = str(e)
            if "Deserialization: Unexpected Encoding Type" in error_message:
                # must be mera1 format, use_legacy
                model = mera.ModelLoader(deployer).from_quantized_mera(
                    source_model_path, use_legacy=True
                )
            else:
                raise(RuntimeError(error_message))

    elif source_model_path.suffix == ".onnx":
        model = mera.ModelLoader(deployer).from_onnx(
            source_model_path,
            shape_mapping=shape_mapping,
            model_info=model_info,
        )
    elif source_model_path.suffix == ".tflite":
        model = mera.ModelLoader(deployer).from_tflite(source_model_path)
    else:  # assume torchscript
        if "_empty" in input_desc:
            raise ValueError(
                "for torchscript model, need input_desc args as {'name': (size, data_type)}"
            )
        model = mera.ModelLoader(deployer).from_pytorch(
            source_model_path,
            input_desc=input_desc,
            layout=layout,
        )

    return model


def get_build_cfg(build_cfg: Union[str, Dict]):
    if isinstance(build_cfg, str):
        # replace quote for json compatibility
        # then turn to dict
        build_cfg = json.loads(str(build_cfg).replace("'", '"'))

    return build_cfg


def deploy_with_mera_wrapper(
    source_model_path: Union[str, Path],
    out_dir: Union[str, Path],
    host_arch: str = "x86",
    platform: Union[str, mera.Platform] = mera.Platform.SAKURA_2C,
    target: Union[str, mera.Target, List] = mera.Target.Interpreter,
    build_cfg: Union[str, Dict] = {},
    shape_mapping: Dict = {},
    model_info: Dict = {},
    input_desc: Dict[str, tuple] = {"_empty": ((1, 3, 640, 640), "float32")},
    **kwargs,
):
    source_model_path = _sanitize_source_model_path(source_model_path)
    out_dir = Path(out_dir).resolve()
    platform = get_device_platform(platform)
    build_cfg = get_build_cfg(build_cfg)
    targets = _sanitize_targets(target=target)

    deploy_dir = out_dir

    # compatibility with MERA1 and MERA2
    if "Deployer" in mera.__dict__:
        deployer_cls = mera.Deployer  # MERA2
    else:
        deployer_cls = mera.TVMDeployer  # MERA1

    with deployer_cls(deploy_dir, overwrite=True) as deployer:
        model = get_model_loaded_with_mera(
            deployer=deployer,
            source_model_path=source_model_path,
            shape_mapping=shape_mapping,
            model_info=model_info,
            input_desc=input_desc,
        )

        # deploy for each target
        for tr in targets:
            deployer.deploy(
                model,
                mera_platform=platform,
                build_config=build_cfg,
                target=tr,
                host_arch=host_arch,
            )

    return deploy_dir
