import os
from flask import Flask, request, jsonify, send_from_directory
# from flask_cors import CORS
import json
import argparse
import os

from backend.json_graph_reader import (
    read_json,
    get_graph_from_json,
    topological_sorted_json,
)
from networkx.readwrite import json_graph

# app = Flask(__name__)
app = Flask(__name__, static_folder="../frontend/build", static_url_path="")


# Enable CORS for all routes (react frontend debug purpose)
# CORS(app, resources={r"/api/*": {"origins": "http://localhost:3000"}})

# Directory to save uploaded files
UPLOAD_FOLDER = "./uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


# Endpoint to serve the React app
@app.route("/")
def serve_react_app():
    return send_from_directory(app.static_folder, "index.html")


# Serve static files
@app.route("/<path:path>")
def serve_static_files(path):
    return send_from_directory(app.static_folder, path)


@app.route("/api/upload", methods=["POST"])
def upload_file():
    response_json = (None, 500)  # a tuple with payload and status code
    if "file" not in request.files:
        response_json = jsonify({"error": "No file part in the request"}), 400

    file = request.files["file"]
    if file.filename == "":
        response_json = jsonify({"error": "No file selected for uploading"}), 400

    # Validate file extension. TODO: Also check file content
    allowed_extensions = {".json"}
    file_extension = os.path.splitext(file.filename)[1].lower()
    if file_extension not in allowed_extensions:
        response_json = jsonify({"error": "Invalid model file."}), 400

    # Process the file to generate graph data
    try:
        data = json.load(file)
        graph = get_graph_from_json(data)
        data1 = topological_sorted_json(graph)
        json_graph_data = json.dumps(data1, indent=4)
        response_json = json_graph_data, 200
    except Exception as e:
        # Handle any processing errors
        response_json = jsonify({"error": f"{str(e)}"}), 500

    # Return the graph data as JSON
    return response_json


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="My Visualizer")
    parser.add_argument(
        "--port", type=int, default=5566, help="Port to run the server on"
    )
    args = parser.parse_args()

    app.run(host="0.0.0.0", port=args.port, debug=True)
