from pathlib import Path
from collections import defaultdict, namedtuple
import json
import networkx as nx
from copy import deepcopy
from pprint import pprint


def construct_subgraphs(data):
    # Create graphs from the json data
    subgraph_holder = {}
    for subgraph in data["subgraphs"]:
        G = nx.DiGraph()
        # first insert nodes
        for node in subgraph["nodes"]:
            node_uid = node["output"]["name"]
            G.add_node(
                node_uid,
                node_local_id=node["output"]["name"],
                op_name=node["op_name"],
                label=node["op_name"],
                attributes={
                    "dtype": node["output"]["dt"],
                    "layout": node["output"]["layout"],
                    "shape": node["output"]["shape"],
                },
                device=subgraph["target_name"],
                subgraph_name=subgraph["subgraph_name"],
                tensor_type=None,  # will be updated later. value could be x, w, b
            )
        # then create connections
        for node in subgraph["nodes"]:
            curr_node_local_uid = node["output"]["name"]
            for tensor_type, input_node_info in node["input_names"].items():
                input_node_local_id = input_node_info["name"]
                G.nodes[input_node_local_id]["tensor_type"] = tensor_type
                G.add_edge(input_node_local_id, curr_node_local_uid)
        subgraph_holder[subgraph["subgraph_name"]] = G
        # save_graph(
        #     G,
        #     graph_name=subgraph["subgraph_name"] + "--" + subgraph["target_name"],
        # )
    print(f"Found {len(subgraph_holder)} subgraph")

    return subgraph_holder


def find_subgraph_joints(subgraphs):
    input_nodes = []
    output_nodes = []
    joints = []
    NodeInfo = namedtuple(
        "NodeInfo", ["node_id", "node_data", "to_be_delete_node_data"]
    )
    Edge = namedtuple("Edge", ["u_of_edge", "v_of_edge"])
    to_be_removed_nodes = []
    # first find all the input and output terminal nodes
    for subgraph_name, subgraph in subgraphs.items():
        for node_id, node_data in subgraph.nodes(data=True):
            predecessors = list(subgraph.predecessors(node_id))
            successors = list(subgraph.successors(node_id))
            # if there is no parent node for u, then it is an input node
            if len(predecessors) == 0:
                in_node_info = NodeInfo(node_id, node_data, None)
                # if it is an intermediate input, we can directly connect to actual ops node
                if len(successors) == 1:
                    next_node = subgraph.nodes(data=True)[successors[0]]
                    in_node_info = NodeInfo(node_id, next_node, node_data)
                input_nodes.append(in_node_info)

            # if there is no child for v, then it is an output node
            if len(successors) == 0:
                # the output node  itself is not useful
                # we need all the nodes that are connected to current output node
                for parent_node_id in predecessors:
                    parent_node_data = subgraph.nodes(data=True)[parent_node_id]
                    out_node_info = NodeInfo(
                        parent_node_id, parent_node_data, node_data
                    )
                    output_nodes.append(out_node_info)

    # not all empty parents nodes are connected to previous output nodes.
    # for example, FloatVecConstant or Int32VecConstant. So skip them
    # a node can be considered as sub-graph input node if is is mentioned as output in some other output node
    # if match found between two terminal, keep the pair to make new edge connection later
    output_set = set([x[0] for x in output_nodes])
    for input_node_id, input_node_data, inp_to_del_node in input_nodes:
        if input_node_id in output_set:
            # TODO: Use hashing instead of list traversing to make the matching faster
            for output_node_id, output_node_data, out_to_del_node in output_nodes:
                if input_node_id == output_node_id:
                    u = make_global_uid(
                        output_node_data["subgraph_name"],
                        output_node_data["node_local_id"],
                    )
                    v = make_global_uid(
                        input_node_data["subgraph_name"],
                        input_node_data["node_local_id"],
                    )
                    # print(f"Connecting u: {u} ---> v: {v}")
                    joints.append(
                        Edge(
                            u_of_edge=(u, output_node_data),
                            v_of_edge=(v, input_node_data),
                        )
                    )

                    to_be_removed_nodes.append(
                        {"u_terminal": out_to_del_node, "v_terminal": inp_to_del_node}
                    )
    return joints, to_be_removed_nodes


def combine_subgraphs(subgraphs, joints):
    final_graph = nx.DiGraph()
    for subgraph_name, subgraph in subgraphs.items():
        print(f"Combining {subgraph_name} to final graph ...")
        # first add nodes
        for node_name, node_data in subgraph.nodes(data=True):
            uid = make_global_uid(subgraph_name, node_name)
            attrs = deepcopy(node_data)
            final_graph.add_node(uid, **attrs)
        # then add edges
        for u, v in subgraph.edges(data=False):
            u_uid = make_global_uid(subgraph_name, u)
            v_uid = make_global_uid(subgraph_name, v)
            # make sure newly created node name for edge also exists in final graph
            assert u_uid in final_graph.nodes, f"Node {u_uid} not found in final graph."
            assert v_uid in final_graph.nodes, f"Node {v_uid} not found in final graph."
            data = populate_edge_info(u_uid, v_uid, final_graph)
            final_graph.add_edge(u_uid, v_uid, **data)
    # at this stage all the subgraphs are still disjoint
    # now add connections between disjoint subgraphs
    for joint in joints:
        # u_id, u_data = joint["u_of_edge"]
        # v_id, v_data = joint["v_of_edge"]
        # u_uid = make_global_uid(u_data["subgraph_name"], u_id)
        # v_uid = make_global_uid(v_data["subgraph_name"], v_id)
        u_uid, u_data = joint.u_of_edge
        v_uid, v_data = joint.v_of_edge
        # print(f"Connecting {u_uid} ---> {v_uid}")
        final_graph.add_edge(u_uid, v_uid)

    # remove_unwanted_nodes(final_graph, need_to_remove)

    print(
        f"Final graph has {final_graph.number_of_nodes()} nodes and {final_graph.number_of_edges()} edges."
    )
    # Check if the final graph is connected
    weakly_connected = list(nx.weakly_connected_components(final_graph))
    if len(weakly_connected) > 1:
        print(f"WARNING: Found {len(weakly_connected)} disjoint sets.")

    return final_graph


def remove_subgraph_terminal_nodes(final_graph, need_to_remove):
    u_terminal_nodes = defaultdict(list)
    v_terminal_nodes = defaultdict(list)
    for item in need_to_remove:
        u_n = item["u_terminal"]
        v_n = item["v_terminal"]
        if u_n is not None:
            u_uid = make_global_uid(u_n["subgraph_name"], u_n["node_local_id"])
            u_terminal_nodes[u_uid].append(u_n)
        if v_n is not None:
            v_uid = make_global_uid(v_n["subgraph_name"], v_n["node_local_id"])
            v_terminal_nodes[v_uid].append(v_n)

    selected_for_removal = []
    for u, v in final_graph.edges():
        # here u_terminal_nodes means GraphOutputs points. So we need to search v inside it
        if v in u_terminal_nodes and v in final_graph.nodes:
            selected_for_removal.append(v)
        # here v_terminal_nodes means input points. So we need to search u inside it
        if u in v_terminal_nodes and u in final_graph.nodes:
            selected_for_removal.append(u)
    for node_id in selected_for_removal:
        if node_id in final_graph.nodes:
            final_graph.remove_node(node_id)
            print(f"Removing node {node_id}")

    # also removed single isolated node
    # find nodes that have no successors and predecessors
    nodes_to_remove = []
    for node in final_graph.nodes:
        pred = list(final_graph.predecessors(node))
        succ = list(final_graph.successors(node))
        if len(pred) == 0 and len(succ) == 0:
            nodes_to_remove.append(node)
    final_graph.remove_nodes_from(nodes_to_remove)

    return final_graph


def get_graph_from_json(data):
    all_subgraph = construct_subgraphs(data)

    # joints, need_to_remove = find_graph_joint_points(all_subgraph)
    joints, need_to_remove = find_subgraph_joints(all_subgraph)
    # joints, need_to_remove  = find_graph_joint_points_v2(all_subgraph)

    final_graph = combine_subgraphs(all_subgraph, joints)
    final_graph = remove_subgraph_terminal_nodes(final_graph, need_to_remove)
    update_nodes_label(final_graph)
    # topological_sorted_json(final_graph)
    return final_graph


def topological_sorted_json(graph):
    # check if the graph has any cycle
    # the find_cycle function will raise an exception if a cycle is found
    try:
        cycle = nx.find_cycle(graph, orientation="original")
    except nx.NetworkXNoCycle:
        cycle = []
    assert len(cycle) == 0, f"Found cycle in the graph: {cycle}"

    topo_order = list(nx.topological_sort(graph))
    ordered_nodes = sorted(graph.nodes(), key=lambda x: topo_order.index(x))

    # Sort edges based on the source node's position
    position = {node: idx for idx, node in enumerate(topo_order)}
    ordered_edges = sorted(graph.edges(), key=lambda edge: position[edge[0]])

    # Modify the custom_node_link to include attributes
    custom_node_link = {
        "directed": graph.is_directed(),
        "multigraph": graph.is_multigraph(),
        "graph": {},  # Include graph-level attributes if any
        "nodes": [{"id": node, **graph.nodes[node]} for node in ordered_nodes],
        "links": [
            {
                "source": u,
                "target": v,
                "label": str(
                    graph.nodes[u]["attributes"]["shape"]
                ),
            }
            for u, v in ordered_edges
        ],
    }
    return custom_node_link


def make_global_uid(subgraph_name, node_local_id):
    return f"{subgraph_name}_{node_local_id}"


def update_nodes_label(graph):
    for node_id, node_data in graph.nodes(data=True):
        op_name = node_data["op_name"]
        label = op_name
        if op_name == "FloatVecConstant" or op_name == "Int32VecConstant":
            label = node_data["tensor_type"]
        elif op_name == "Var":
            label = node_data["tensor_type"]
        elif op_name == "FileBackedConstant" and node_data["tensor_type"] != "":
            label = node_data["tensor_type"]
        graph.nodes[node_id]["label"] = label


def populate_edge_info(u, v, graph):
    viz_obj_shape = "RECTANGLE"
    line_minlen = 10
    line_weight = 5
    relative_position = "top"  # top, bottom, left, right
    tensor_shape = None
    tensor_size = None
    label = ""

    u_node = graph.nodes(data=True)[u]
    v_node = graph.nodes(data=True)[v]
    if u_node["op_name"] == "FloatVecConstant":
        viz_obj_shape = "CIRCLE"
        line_minlen = 1
        line_weight = 10

    if u_node["op_name"] == "Int32VecConstant":
        viz_obj_shape = "CIRCLE"
        line_minlen = 1
        line_weight = 10

    data = {
        "label": label,
        "viz_obj_shape": viz_obj_shape,
        "line_minlen": line_minlen,
        "line_weight": line_weight,
        "relative_position": relative_position,
        "tensor_shape": tensor_shape,
        "tensor_size": tensor_size,
    }
    return data


def is_last_output_node(graph, node_id):
    successors = list(graph.successors(node_id))
    # first make sure it is leaf node
    if len(successors) == 0:
        predecessors = list(graph.predecessors(node_id))
        for pred_node in predecessors:
            pred_successors = list(graph.successors(pred_node))
            if len(pred_successors) > 1:
                return False
    return True


def remove_unwanted_nodes(graph, need_to_remove):
    # remove the nodes
    deleted_set = set()
    for node_id, node_data in need_to_remove:
        uid = make_global_uid(node_data["subgraph_name"], node_id)
        successors = list(graph.successors(uid))
        predecessors = list(graph.predecessors(uid))
        if not is_last_output_node(graph, uid):
            print(f"Removing node {uid}")
            graph.remove_node(uid)
            deleted_set.add(uid)
    # remove the edges

    # Remove var nodes
    edges = list(graph.edges(data=False))
    for u, v in edges:
        v_node = graph.nodes(data=True)[v]
        if v_node["op_name"] == "Var":
            predecessors = list(graph.predecessors(v))
            successors = list(graph.successors(v))
            if len(predecessors) > 0 and len(successors) > 0:
                # connect the predecessor and successor to skip the var node
                for pred in predecessors:
                    for succ in successors:
                        graph.add_edge(pred, succ)
                        print(f"Connecting {pred} ---> {succ}")
                graph.remove_edge(u, v)
                graph.remove_node(v)


# read json file
def read_json(file_path):
    with open(file_path, "r") as file:
        data = json.load(file)
    return data


def save_graph(G, graph_name):
    out_path = Path(__file__).resolve().parent / "dummy_model" / "graph"
    out_path.mkdir(parents=True, exist_ok=True)
    # Save as SVG using Graphviz layout
    nx.nx_agraph.write_dot(G, out_path / f"{graph_name}.dot")  # Save as DOT file
    # nx.drawing.nx_agraph.to_agraph(G).draw(
    #     out_path / f"{graph_name}.svg", prog="dot", format="svg"
    # )

    # Convert to AGraph and apply styling
    A = nx.drawing.nx_agraph.to_agraph(G)
    for node in A.nodes():
        new_label = (
            f"{G.nodes[node]['node_local_id']}"  # bold_code
            + f"\nop_name: {G.nodes[node]['op_name']}"
            + f"\ninputs: {list(G.predecessors(node))}"
            + f"\noutputs: {list(G.successors(node))}"
        )

        node.attr["label"] = new_label
        node.attr["style"] = "filled"
        color = "lightblue"
        if G.nodes[node]["device"] == "CPU":
            color = "salmon"
        elif G.nodes[node]["device"] == "SAKURA_II":
            color = "lightgreen"
        node.attr["fillcolor"] = color

    A.draw(out_path / f"{graph_name}.svg", prog="dot", format="svg")

    print("Graph saved as graph.svg")


if __name__ == "__main__":
    base_path = Path("./dummy_model/")
    json_file_4 = "model_subgraphs_dummy.json"
    json_path = base_path / json_file_4

    data = read_json(json_path)
    graph = get_graph_from_json(data)
    data1 = topological_sorted_json(graph)
    json_graph_data = json.dumps(data1, indent=4)
